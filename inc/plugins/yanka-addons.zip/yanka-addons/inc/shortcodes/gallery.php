<?php
if( ! function_exists( 'yanka_shortcode_gallery' ) ) {
    function yanka_shortcode_gallery( $atts, $content = null ) {
        $output = $size = $spacing_padding = $spacing_margin = '';

		extract( shortcode_atts( array(
			'images'         	  => '',
            'img_size'            => 'full',
            'gallery_type'        => 'grid',
            'on_click'            => 'lightbox',
            'spacing'             => '10',
            'columns'             => '3',
            'enterance_animation' => '',
			'el_class'            => '',
            'css_animation'            => '',
			'css' 				  => '',
		), $atts ) );

		$classes = array( 'yanka-gallery' );

        if ( ! empty( $gallery_type ) ) {
            $classes[] = 'gallery-design-' . esc_attr( $gallery_type );
        }

        if ( isset($columns) && $columns != '' ) {
            $classes[] = 'layout-columns-' . esc_attr( $columns );
        }

        if ( isset($spacing) && $spacing != '' ) {
            $classes[] = 'layout-spacing-' . esc_attr( $spacing );
        }

        if ( '' !== $css_animation ) {
            $classes[] = getCSSAnimation( $css_animation );
        }

        if( 'lightbox' === $on_click ) {
            wp_enqueue_script( 'prettyphoto' );
    		wp_enqueue_style( 'prettyphoto' );
		}


        if ( ! empty( $el_class ) ) {
            $classes[] = esc_attr( $el_class );
        }

        if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

        $images = explode(',', $images);

        if (isset($img_size) && $img_size != '') {
            $size = $img_size;
        }

        ob_start(); ?>
        <div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
            <div class="gallery-wrapper ">
            <?php if ( count($images) > 0 ): ?>
                <?php $i=0; foreach ($images as $img_id):
                    $i++;
                    $attachment = get_post( $img_id );
                    //$title = trim( strip_tags( $attachment->post_title ) );
                    $img = wpb_getImageBySize( array( 'attach_id' => $img_id, 'thumb_size' => $img_size, 'class' => 'yanka-gallery-image image-' . $i ) );
                    $link = $img['p_img_large']['0'];
                    if( 'links' === $on_click ) {
                        $link = (isset( $custom_links[$i-1] ) ? $custom_links[$i-1] : '' );
                    }
                    ?>
                    <div class="product-item item <?php echo 'mb-' . esc_attr( $spacing ); ?>">
                        <?php if ( $on_click != 'none' ): ?>
                            <a href="<?php echo esc_url( $link ); ?>" class="prettyphoto" data-rel="prettyPhoto[rel-<?php echo get_the_ID(); ?>]" data-index="<?php echo esc_attr( $i ); ?>" data-width="<?php echo esc_attr( $img['p_img_large']['1'] ); ?>" data-height="<?php echo esc_attr( $img['p_img_large']['2'] ); ?>">
                        <?php endif ?>

                        <?php if ( isset($img['thumbnail']) && $img['thumbnail'] != '' ): ?>
                            <?php echo wp_kses( $img['thumbnail'], array( 'img' => array('class' => true,'width' => true,'height' => true,'src' => true,'alt' => true) ) );?>
                        <?php endif; ?>

                        <?php if ( $on_click != 'none' ): ?>
                            </a>
                        <?php endif ?>
                    </div>
                <?php endforeach ?>
            <?php endif ?>
            </div>
        </div>
        <?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
    }
    add_shortcode( 'jms_gallery', 'yanka_shortcode_gallery' );
}
