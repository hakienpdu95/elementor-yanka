<?php
/**
 * Service shortcode.
 */

if ( ! function_exists( 'yanka_shortcode_service' ) ) {
	function yanka_shortcode_service( $atts, $content = null ) {
		$output = $icon_color_style = $subtitle_color_style = $title_color_style = $icon_fontawesome = $title_size = $icon_stroke = '';

		extract( shortcode_atts( array(
			'type'             => 'icon',
			'icon_type'        => '',
			'icon_fontawesome' => '',
			'icon_stroke'      => '',
			'image'            => '',
			'icon_size'        => '',
			'alignment'        => 'top',
			'title'            => '',
			'subtitle'         => '',
			'title_size'	   => 'default',
			'text_alignment'   => 'left',
			'icon_color'       => '',
			'title_color'      => '',
			'subtitle_color'   => '',
			'css_animation'			=> '',
			'el_class'         => '',
            'css'     		   => ''
		), $atts ) );

		$classes = array('service-elements');

		if ( isset($icon_color) && $icon_color != '' ) {
			$icon_color_style = ' style="color: ' . esc_attr( $icon_color ) . ';"';
		}

		if ( isset($title_color) && $title_color != '' ) {
			$title_color_style = ' style="color: ' . esc_attr( $title_color ) . ';"';
		}

		if ( isset($subtitle_color) && $subtitle_color != '' ) {
			$subtitle_color_style = ' style="color: ' . esc_attr( $subtitle_color ) . ';"';
		}

        if ( isset($alignment) && ! empty( $alignment ) ) {
			$classes[] = 'service-align-' . esc_attr($alignment);
		}

		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

        if ( isset($el_class) && ! empty( $el_class ) ) {
			$classes[] = esc_attr($el_class);
		}

		if ( isset($css) && !empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

        $icon_class = array();

        if ( isset($icon_size) && ! empty( $icon_size ) ) {
			$icon_class[] = 'size-icon-' . esc_attr($icon_size);
		}


		$title_class = array();

		if ( isset($title_size) && ! empty( $title_size ) ) {
			$title_class[] = 'size-title-' . esc_attr($title_size);
		}
		
		if ( isset($alignment) && ! empty( $alignment ) ) {
			$title_class[] = 'text-' . esc_attr($text_alignment);
		}


		ob_start();
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
			<div class="service-box-icon <?php echo esc_attr( implode( ' ', $icon_class ) ); ?>">
				<?php if ( isset($type) && $type == 'icon' ) : ?>
					<?php if ( isset($icon_fontawesome) && $icon_fontawesome != '' && $icon_type == 'fontawesome' ) : ?>
						<span class="vc_icon_element-icon <?php echo esc_attr($icon_fontawesome); ?>"<?php echo $icon_color_style; ?>></span>
					<?php endif; ?>

					<?php if ( isset($icon_stroke) && $icon_stroke != '' && $icon_type == 'stroke') : ?>
						<span class="vc_icon_element-icon <?php echo esc_attr($icon_stroke); ?>"<?php echo $icon_color_style; ?>></span>
					<?php endif; ?>
				<?php else : ?>
					<?php
					    $img_id = preg_replace( '/[^\d]/', '', $image );
					    $image  = wpb_getImageBySize( array( 'attach_id' => $img_id ) );
					?>
					<img src="<?php echo esc_url( $image['p_img_large'][0] ); ?>" width="<?php echo esc_attr( $image['p_img_large'][1] ); ?>" height="<?php echo esc_attr( $image['p_img_large'][2] ); ?>" alt="sss" />
				<?php endif; ?>
			</div>
			<div class="service-box-content <?php echo esc_attr( implode( ' ', $title_class ) ); ?>">
				<div class="service-box-inner">
					<?php if ( isset( $title ) && $title != '' ) : ?>
						<h4 class="service-title"<?php echo $title_color_style; ?>>
							<?php echo esc_attr( $title ); ?>
						</h4>
					<?php endif; ?>
					<?php if ( isset( $subtitle ) && $subtitle != '' ) : ?>
						<p class="service-subtitle"<?php echo $subtitle_color_style; ?>>
							<?php echo esc_attr( $subtitle ); ?>
						</p>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'jms_service', 'yanka_shortcode_service' );
}
