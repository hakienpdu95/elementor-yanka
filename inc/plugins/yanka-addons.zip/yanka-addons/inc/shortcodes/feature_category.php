<?php
if ( ! function_exists( 'yanka_shortcode_product_categories' ) ) {
	function yanka_shortcode_product_categories( $atts, $content = null ) {
		$output = '';

		extract( shortcode_atts( array(
			'orderby'           => '',
			'order'             => 'ASC',
			'columns'           => '4',
			'categories_design' => 'grid',
			'hide_empty'        => 'yes',
			'ids'               => '',
			'spacing'           => 30,
			'el_class'          => '',
			'css' 				=> '',
			'css_animation' 				=> '',
			'hover_effect'		=> '1',
			'style_navigation'	 => 'icon_arrow',
		), $atts ) );

		$id = rand(100, 9999);

		$classes = array('jmsproductcategories-elements');

		if ( isset($style_navigation) && $style_navigation == 'icon_arrow' ) {
			$classes[] = 'icon_arrow';
		}elseif( isset($style_navigation) && $style_navigation == 'icon_box_arrow' ) {
			$classes[] = 'icon_box_arrow';
		}

		if ( isset($el_class) && $el_class != '' ) {
			$classes[] = esc_attr( $el_class );
		}
		
		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }
        
        if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		$classes_effect = array();

		if ( ! empty( $hover_effect ) ) {
			$classes_effect[] = 'box-effect image-effect-' . esc_attr($hover_effect);
		}

		if ( isset( $ids ) ) {
			$ids = explode( ',', $ids );
			$ids = array_map( 'trim', $ids );
		} else {
			$ids = array();
		}

		$hide_empty = ( $hide_empty == 'yes' || $hide_empty == 1 ) ? 1 : 0;

		// get terms
		$args = array(
			'order'      => $order,
			'hide_empty' => $hide_empty,
			'include'    => $ids,
			'pad_counts' => true,
			'child_of'   => false
		);

		if ( $orderby ) $args['orderby'] = $orderby;

		$product_categories = get_terms( 'product_cat', $args );

        ob_start(); ?>

		<?php if ( $product_categories ) : ?>

	        <div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
				<?php if ( isset( $categories_design ) && $categories_design == 'carousel' ) : ?>
					<div class="product-categories-carousel-<?php echo intval($id); ?> owl-carousel owl-theme">
				<?php else : ?>
					<div class="products row product-design-grid masonry-container layout-columns-<?php echo esc_attr( $columns ); ?> layout-spacing-<?php echo esc_attr( $spacing ); ?>">
				<?php endif; ?>

					<?php foreach ( $product_categories as $category ): ?>
						<div class="category-item item mb-<?php echo esc_attr( $spacing ); ?> <?php echo esc_attr( implode( ' ', $classes_effect ) ); ?>">
							<?php
								wc_get_template( 'content-product_cat.php', array(
									'category' => $category
								) );
							?>
						</div>
					<?php endforeach; ?>

	            </div>
	        </div>

			<?php
			if ( isset($categories_design) && $categories_design == 'carousel' ) {
				wp_add_inline_script( 'yanka-theme', yanka_product_categories_carousel_js( $atts, $id ), 'after' );
			}
			?>

		<?php endif;

		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'jms_product_categories', 'yanka_shortcode_product_categories' );
}

if( ! function_exists( 'yanka_product_categories_carousel_js' ) ) {
	function yanka_product_categories_carousel_js( $atts, $id ) {
		$output = '';
		extract(shortcode_atts( array(
			'items_desktop'       => '4',
            'items_small_desktop' => '4',
            'items_tablet'        => '3',
            'items_mobile'        => '2',
            'items_small_mobile'  => '1',
            'navigation'          => 'yes',
            'pagination'          => 'no',
            'autoplay'            => 'no',
            'loop'                => 'no',
		), $atts ));
		ob_start();
		?>
			jQuery(document).ready(function($) {
				var rtl = false;
			    if ($('body').hasClass('rtl')) rtl = true;

				<?php
				if ( isset($navigation) && $navigation == 'yes' ) {
					$navigation = 'true';
				} else {
					$navigation = 'false';
				}

				if ( isset($pagination) && $pagination == 'yes' ) {
					$pagination = 'true';
				} else {
					$pagination = 'false';
				}

				if ( isset($autoplay) && $autoplay == 'yes' ) {
					$autoplay = 'true';
				} else {
					$autoplay = 'false';
				}

				if ( isset($loop) && $loop == 'yes' ) {
					$loop = 'true';
				} else {
					$loop = 'false';
				}

				?>

				$('.product-categories-carousel-<?php echo esc_attr($id); ?>').owlCarousel({
			        responsive : {
						320 : {
			        		items: <?php echo intval($items_small_mobile); ?>,
			        	},
						445 : {
			        		items: <?php echo intval($items_mobile); ?>,
			        	},
						768 : {
			        		items: <?php echo intval($items_tablet); ?>,
			        	},
					    991 : {
					        items: <?php echo intval($items_small_desktop); ?>,
					    },
					    1199 : {
					        items: <?php echo intval($items_desktop); ?>,
					    }
					},
					rtl: rtl,
			        margin: 30,
					nav: <?php echo esc_attr( $navigation ); ?>,
					dots: <?php echo esc_attr( $pagination ); ?>,
					autoplay: <?php echo esc_attr( $autoplay ); ?>,
					loop: <?php echo esc_attr( $loop ); ?>,
			        smartSpeed: 250,
					navText: ['prew<i class="icon-arrow yanka-icon-angle-left"></i>','next<i class="icon-arrow yanka-icon-angle-right"></i>']
			    });
			});

		<?php
		return ob_get_clean();
	}
}
