<?php

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'yanka_shortcode_brand_carousel' ) ) {
	function yanka_shortcode_brand_carousel( $atts, $content = null ) {
		$output = $title = $description = $images_brand = $image_brand = $total_items = $number_of_rows = $items_space = $items_desktop = $items_small_desktop = $items_tablet = $items_mobile = $items_small_mobile = $navigation = $pagination = $autoplay = $loop = $el_class = $css = $style_navigation = '';

		extract( shortcode_atts( array(
			'images_brand'        => '',
			'items_space'         => '40',
            'items_desktop'       => '6',
            'items_small_desktop' => '5',
            'items_tablet'        => '3',
            'items_mobile'        => '2',
            'items_small_mobile'  => '2',
            'navigation'          => 'no',
            'pagination'          => 'no',
            'autoplay'            => 'no',
            'loop'                => 'no',
			'css_animation'            => '',
			'el_class'            => '',
			'css' 				  => '',
			'style_navigation'	  => 'icon_arrow',
		), $atts ) );

        $rd_number = rand();

		$classes = array('jmsbrand-box');

		if ( ! empty( $el_class ) ) {
			$classes[] = esc_attr($el_class);
		}

		if ( isset($style_navigation) && $style_navigation == 'icon_arrow' ) {
			$classes[] = 'icon_arrow';
		}elseif( isset($style_navigation) && $style_navigation == 'icon_box_arrow' ) {
			$classes[] = 'icon_box_arrow';
		}

		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		// attr slider
		$attr_slider = $dataCarousel = array();

		if ( ! empty( $items_desktop ) ) {
			$attr_slider[] = '"itemDesktop": "' . intval($items_desktop) . '"';
			$attr_slider[] = '"smartSpeed": 250';
		}

		if ( ! empty( $items_small_desktop ) ) {
			$attr_slider[] = '"itemSmallDesktop": "' . intval($items_small_desktop) . '"';
		}

		if ( ! empty( $items_tablet ) ) {
			$attr_slider[] = '"itemTablet": "' . intval($items_tablet) . '"';
		}

		if ( ! empty( $items_mobile ) ) {
			$attr_slider[] = '"itemMobile": "' . intval($items_mobile) . '"';
		}

		if ( ! empty( $items_small_mobile ) ) {
			$attr_slider[] = '"itemSmallMobile": "' . intval($items_small_mobile) . '"';
		}

		if ( ! empty( $items_space ) ) {
			$attr_slider[] = '"margin": ' . esc_attr($items_space);
		}

		if ( isset($navigation) && $navigation == 'yes'  ) {
			$attr_slider[] = '"navigation": true';
		} else {
			$attr_slider[] = '"navigation": false';
		}

		if ( isset($pagination) && $pagination == 'yes'  ) {
			$attr_slider[] = '"pagination": true';
		} else {
			$attr_slider[] = '"pagination": false';
		}

		if ( isset($autoplay) && $autoplay == 'yes'  ) {
			$attr_slider[] = '"autoplay": true';
		} else {
			$attr_slider[] = '"autoplay": false';
		}

		if ( isset($loop) && $loop == 'yes'  ) {
			$attr_slider[] = '"loop": true';
		} else {
			$attr_slider[] = '"loop": false';
		}

		if ( ! empty( $attr_slider ) ) {
			$dataCarousel[] = 'data-carousel=\'{"selector": ".brand-carousel-'. intval($rd_number) .'", ' . esc_attr( implode( ', ', $attr_slider ) ) . '}\'';
		}
		$images_url = vc_param_group_parse_atts($atts['images_brand']);

        ob_start(); ?>
        <div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" >
            <div class="brand-carousel-<?php echo intval($rd_number); ?> owl-carousel owl-theme" <?php echo implode( ' ', $dataCarousel ); ?>>
				<?php
				foreach($images_url as $image_url) {
					$_img = wp_get_attachment_image_src($image_url['image_brand'], 'full');
					$img = $_img[0];
					?>
					<div class="item tc">
						<a href="<?php if (isset($image_url['link_brand']) && $image_url['link_brand'] !==''){echo esc_attr($image_url['link_brand']);} ?>" >
							<img src="<?php echo esc_url( $img ); ?>" alt="">
						</a>
						<?php if (isset($image_url['title_brand']) && $image_url['title_brand'] !==''){ ?>
							<h3 class="title-brand"> <?php echo esc_attr($image_url['title_brand']); ?> </h3>
						<?php } ?>
					</div>
					<?php
				}
				?>
        	</div>
        </div>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'yanka_brand_carousel', 'yanka_shortcode_brand_carousel' );
}
