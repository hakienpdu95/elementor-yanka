<?php
/**
* ------------------------------------------------------------------------------------------------
* HTML block shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_html_block_shortcode' ) ) {
	function yanka_html_block_shortcode($atts) {
		extract(shortcode_atts(array(
			'id' => 0
		), $atts));

		return yanka_get_html_block($id);
	}
	add_shortcode( 'html_block', 'yanka_html_block_shortcode' );
}
