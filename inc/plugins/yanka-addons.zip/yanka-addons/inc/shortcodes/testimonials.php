<?php

/**
* ------------------------------------------------------------------------------------------------
* Testimonials shortcodes
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_shortcode_testimonials' ) ) {
	function yanka_shortcode_testimonials($atts = array(), $content = null) {
		$output = $class = '';

        extract( shortcode_atts( array(
			'title'               => '',
            'layout'              => 'slider',
            'style'               => 'standard',
            'align'               => 'center',
            'columns'             => 3,
			'color_text'          => 'dark',
            'el_class'            => '',
            'css_animation'            => '',
			'items_spacing'       => '40',
            'items_desktop'       => '1',
            'items_small_desktop' => '1',
            'items_tablet'        => '1',
            'items_mobile'        => '1',
            'items_small_mobile'  => '1',
            'navigation'          => 'no',
            'pagination'          => 'yes',
            'autoplay'            => 'no',
            'loop'                => 'no',
            'style_navigation'	 => 'icon_arrow'
		), $atts ) );

		$class .= ' testimonials-' . esc_attr($layout);
		$class .= ' testimonials-style-' . esc_attr($style);
		$class .= ' testimonials-columns-' . esc_attr($columns);
		$class .= ' testimonials-align-' . esc_attr($align);
		$class .= ' testimonials-color-' . esc_attr($color_text);
		$class .= ' '. esc_attr($style_navigation);

        $carousel_id = 'carousel-' . rand( 1000, 10000);

		$slider_class = '';
		if( $layout == 'slider' ) {
            $slider_class .= ' ' . $carousel_id . ' owl-carousel owl-theme';
        }

		$class .= ' ' . $el_class;

		if ( '' !== $css_animation ) {
			$class .= ' ' .getCSSAnimation( $css_animation );
		}

		ob_start(); ?>
			<div class="jmstestimonial-box<?php echo esc_attr( $class ); ?>">
                <?php if ( isset($title) && $title != '' ): ?>
                    <div class="addon-title">
            			<h3><?php echo esc_html( $title ); ?></h3>
                    </div>
                <?php endif; ?>
				<div class="testimonials<?php echo esc_attr( $slider_class ); ?>">
					<?php echo do_shortcode( shortcode_unautop( $content )); ?>
				</div>
			</div>
		<?php
		if( $layout == 'slider' ) {
			wp_add_inline_script( 'yanka-theme', yanka_testimonial_carousel_js( $atts, $carousel_id ), 'after' );
		}

		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'testimonials', 'yanka_shortcode_testimonials' );
}

if ( !function_exists('yanka_testimonial_carousel_js') ) {
	function yanka_testimonial_carousel_js( $atts, $carousel_id ) {
		$output = $class = '';

        extract( shortcode_atts( array(
			'items_spacing'       => '40',
            'items_desktop'       => '1',
            'items_small_desktop' => '1',
            'items_tablet'        => '1',
            'items_mobile'        => '1',
            'items_small_mobile'  => '1',
            'navigation'          => 'no',
            'pagination'          => 'yes',
            'autoplay'            => 'no',
            'loop'                => 'no',
		), $atts ) );

		ob_start();
		?>
			jQuery(document).ready(function($) {
				var rtl = false;
			    if ($('body').hasClass('rtl')) rtl = true;

				$('.<?php echo esc_js($carousel_id); ?>').owlCarousel({
					responsive : {
						320 : {
							items: <?php if( (int) $items_small_mobile > 0) { echo intval($items_small_mobile); } else { echo '1'; } ?>,
						},
						480 : {
							items: <?php if( (int) $items_mobile > 0) { echo intval($items_mobile); } else { echo '1'; } ?>,
						},
						768 : {
							items: <?php if( (int) $items_tablet > 0) { echo intval($items_tablet); } else { echo '1'; } ?>,
						},
						991 : {
							items: <?php if( (int) $items_small_desktop > 0) { echo intval($items_small_desktop); } else { echo '1'; } ?>,
						},
						1199 : {
							items: <?php if( (int) $items_desktop > 0) { echo intval($items_desktop); } else { echo '1'; } ?>,
						}
					},
					stagePadding: 15,
					lazyLoad : true,
					rtl: rtl,
					margin: <?php if( (int) $items_spacing > 0) { echo esc_attr($items_spacing); } else { echo '40'; } ?>,
					dots: <?php if( $pagination && $pagination == 'yes'  ) { echo 'true'; } else { echo 'false'; } ?>,
					nav: <?php if( $navigation && $navigation == 'yes' ) { echo 'true'; } else { echo 'false'; } ?>,
					autoplay: <?php if( $autoplay && $autoplay == 'yes' ) { echo 'true'; } else { echo 'false'; } ?>,
					loop: <?php if( $loop && $loop == 'yes' ) { echo 'true'; } else { echo 'false'; } ?>,
					autoplayTimeout: 5000,
					smartSpeed: 250,
					navText: ['Prew','Next']
			    });
			});

		<?php
		return ob_get_clean();
	}
}

if( ! function_exists( 'yanka_shortcode_testimonial' ) ) {
	function yanka_shortcode_testimonial($atts, $content) {
		if( ! function_exists( 'wpb_getImageBySize' ) ) return;
		$output = $class = '';

        extract(shortcode_atts( array(
			'image'    => '',
			'img_size' => '80x80',
			'title_star'   => '0',
			'title_review'   => '',
			'name'     => '',
			'title'    => '',
			'content_position'    => 'no',
			'el_class' => ''
		), $atts ));

		$img_id = preg_replace( '/[^\d]/', '', $image );

		$img = wpb_getImageBySize( array( 'attach_id' => $img_id, 'thumb_size' => $img_size, 'class' => 'testimonial-avatar-image' ) );

        if ( isset($el_class) && $el_class != '' ) {
            $class .= ' ' . esc_attr($el_class);
        }

		ob_start(); ?>


		<a href="" tabindex="0" class="testimonial-box<?php echo esc_attr( $class ); ?>">
		    <div class="pt-reviewsbox">
		        <div class="pt-reviewsbox-description">
		            <div class="pt-reviewsbox-title">
		                <h5 class="pt-title">
							<?php if ( $title_review ): ?>
								<?php echo esc_html( $title_review ); ?>
							<?php endif ?>                	
		                </h5>

		                <div class="pt-rating">
		                	<?php if( $title_star == 0 ) : ?>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i><svg><use xlink:href="#icon-review"></use></svg></i>
		                	<?php else : ?>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                		<i class="pt-star"><svg><use xlink:href="#icon-review"></use></svg></i>
		                	<?php endif; ?>
		                </div>

		            </div>
		    		<?php if ($content_position !== 'yes'){ ?>
						<div class="pt-content">
							<?php echo do_shortcode( shortcode_unautop( $content )); ?>
						</div>
					<?php } ?>
		        </div>



		        <div class="pt-reviewsbox-author">

		            <div class="pt-img">
						<?php if ( $img['thumbnail'] != ''): ?>
							<?php echo wp_kses( $img['thumbnail'], array( 'img' => array('class' => true,'width' => true,'height' => true,'src' => true,'alt' => true) ) );?>
						<?php endif ?>                
		            </div>

		            <div class="pt-title">
		            	<strong>
							<?php if ( $name ): ?>
								<?php echo esc_html( $name ); ?>
							<?php endif ?>            		
		            	</strong><?php if ( $title ): ?> — <?php echo esc_html( $title ); ?><?php endif ?>
		            </div>
		        </div>

		    </div>
		</a>


		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'testimonial', 'yanka_shortcode_testimonial' );
}
