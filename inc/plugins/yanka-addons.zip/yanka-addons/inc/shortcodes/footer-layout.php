<?php
/**
* ------------------------------------------------------------------------------------------------
* HTML block shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_footer_layout_shortcode' ) ) {
	function yanka_footer_layout_shortcode($atts) {
		extract(shortcode_atts(array(
			'id' => 0
		), $atts));

		return yanka_get_footer_layout($id);
	}
	add_shortcode( 'footer_layout', 'yanka_footer_layout_shortcode' );
}
