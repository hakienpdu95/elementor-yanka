<?php
/**
* ------------------------------------------------------------------------------------------------
* Team member shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_shortcode_social_icons' )) {
	function yanka_shortcode_social_icons($atts, $content = '') {
		$output = '';
		extract( shortcode_atts( array(
            'title_social'=> '',
            'twitter'     => '',
	        'facebook'    => '',
	        'google_plus' => '',
	        'skype'       => '',
	        'linkedin'    => '',
	        'instagram'   => '',
            'pinterest'   => '',
	        'align'       => 'left',
			'style'       => 'default',
			'size'        => 'default',
            'color'       => 'default',
            'css_animation'       => '',
			'el_class'    => ''
		), $atts ) );

        $classes = array('yanka-social-icons flex');

        if ( '' !== $css_animation ) {
            $classes[] = getCSSAnimation( $css_animation );
        }

        if ($el_class != '') $classes[] = $el_class;
        if ($align != '') $classes[] = 'icon-align-' . esc_attr( $align );
        if ($style != '') $classes[] = 'icon-style-' . esc_attr( $style );
        if ($size != '') $classes[] = 'icon-size-' . esc_attr( $size );
        if ($color != '') $classes[] = 'icon-color-' . esc_attr( $color );

		ob_start();

        if ($linkedin != '' || $twitter != '' || $facebook != '' || $skype != '' || $google_plus != '' || $instagram != '') : ?>
           <div class="yanka-social-box">
           <div class="yanka-social-box-title"><?php echo esc_attr( $title_social ); ?></div>
           <div class="<?php echo implode(' ', $classes); ?>">
                <?php if ($facebook != '') : ?>
                    <div class="yanka-social-icon social-facebook"><a href="<?php echo esc_url( $facebook ); ?>">
                        <svg width="11" height="18" viewBox="0 0 11 18">
                            <use xlink:href="#icon-social_icon_facebook"></use>
                        </svg>
                    </a></div>
                <?php endif; ?>
                <?php if ($twitter != '') : ?>
                    <div class="yanka-social-icon social-twitter"><a href="<?php echo esc_url( $twitter ); ?>"><i class="fa fa-twitter"></i></a></div>
                <?php endif; ?>
                <?php if ($google_plus != '') : ?>
                    <div class="yanka-social-icon social-google-plus"><a href="<?php echo esc_url( $google_plus ); ?>"><i class="fa fa-google-plus"></i></a></div>
                <?php endif; ?>
                <?php if ($linkedin != '') : ?>
                    <div class="yanka-social-icon social-linkedin"><a href="<?php echo esc_url( $linkedin ); ?>"><i class="fa fa-linkedin"></i></a></div>
                <?php endif; ?>
                <?php if ($skype != '') : ?>
                    <div class="yanka-social-icon social-skype"><a href="<?php echo esc_url( $skype ); ?>"><i class="fa fa-skype"></i></a></div>
                <?php endif; ?>
                <?php if ($instagram != '') : ?>
                    <div class="yanka-social-icon social-instagram"><a href="<?php echo esc_url( $instagram ); ?>">
                        <svg width="18" height="18" viewBox="0 0 18 18">
                            <use xlink:href="#icon-social_icon_instagram"></use>
                        </svg>
                    </a></div>
                <?php endif; ?>
                <?php if ($pinterest != '') : ?>
                    <div class="yanka-social-icon social-pinterest"><a href="<?php echo esc_url( $pinterest ); ?>">
                        <svg width="18" height="19" viewBox="0 0 18 19">
                            <use xlink:href="#icon-social_icon_1"></use>
                        </svg>
                    </a></div>
                <?php endif; ?>
            </div>
            </div>
        <?php endif; ?>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
    add_shortcode( 'yanka_social_icons', 'yanka_shortcode_social_icons' );
}
