<?php

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'yanka_shortcode_title' ) ) {
	function yanka_shortcode_title( $atts, $content = null ) {
		$output = $subtitle_class = '';

		extract( shortcode_atts( array(
			'title'          		=> 'Custom Title',
			'title_font_family'     => '',
			'title_type'          	=> '',
			'title_size'          	=> '',
			'title_line_height'     => '',
			'title_spacing'         => '',
			'title_margin'          => '',
			'title_weight'          => '',
			'title_color'           => '',
			'title_align'           => 'center',
			'title_width'           => '',
			'css_animation'				=> '',
			'title_use_theme_fonts' => '',
			'title_google_fonts'    => '',
			'el_class'       		=> '',
            'css'   				=> ''
		), $atts ) );

        $classes = array( 'addon-title' );
        
		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		if ( isset( $title_type ) &&  ('' !== $title_type) ) {
			$classes[] = 'title-type-'. esc_attr($title_type);
		}

		if ( isset( $title_align ) &&  ('' !== $title_align) ) {
			$classes[] = 'text-'. esc_attr($title_align);
		}

		if ( isset( $title_font_family ) &&  ('' !== $title_font_family) ) {
			$classes[] = esc_attr($title_font_family). '-font';
		}

        $google_fonts_obj = new Vc_Google_Fonts();
		$google_fonts_field_settings = isset( $google_fonts_field['settings'], $google_fonts_field['settings']['fields'] ) ? $google_fonts_field['settings']['fields'] : array();

        $title_style = array();

		$title_google_fonts_data = strlen( $title_google_fonts ) > 0 ? $google_fonts_obj->_vc_google_fonts_parse_attributes( $google_fonts_field_settings, $title_google_fonts ) : '';

		if ( ( ! isset( $title_use_theme_fonts ) || 'yes' !== $title_use_theme_fonts ) && ! empty( $title_google_fonts_data ) && isset( $title_google_fonts_data['values'], $title_google_fonts_data['values']['font_family'], $title_google_fonts_data['values']['font_style'] ) ) {
			$title_google_fonts_family = explode( ':', $title_google_fonts_data['values']['font_family'] );
			$title_style[] = 'font-family:' . $title_google_fonts_family[0];
			$title_google_fonts_styles = explode( ':', $title_google_fonts_data['values']['font_style'] );
			$title_style[] = 'font-weight:' . $title_google_fonts_styles[1];
			$title_style[] = 'font-style:' . $title_google_fonts_styles[2];
		}

		if ( '' !== $title_size && is_numeric($title_size)) {
			$title_style[] = 'font-size: '. esc_attr($title_size)/16 .'em';
		}
		if ( '' !== $title_line_height && is_numeric($title_line_height)) {
			$title_style[] = 'line-height: '. esc_attr($title_line_height) .'px';
		}

		if ( '' !== $title_color ) {
			$title_style[] = 'color: '. $title_color;
		}

		if ( '' !== $title_spacing && is_numeric($title_spacing) ) {
			$title_style[] = 'letter-spacing: '. esc_attr($title_spacing)/16 .'em';
		}

		if ( '' !== $title_weight && 'default' !== $title_weight ) {
			$title_style[] = 'font-weight: '. esc_attr($title_weight);
		}

		if ( '' !== $title_margin && is_numeric($title_margin) ) {
			$title_style[] = 'margin-bottom: '. esc_attr($title_margin).'px';
		}

		if ( '' !== $title_width && is_numeric($title_width)) {
			$title_style[] = 'width: '. esc_attr($title_width).'%';
		}

		// Custom class
		if ( isset( $el_class ) && $el_class != '' ) {
			$classes[] = esc_attr($el_class);
		}

		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

		ob_start();

		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">

			<div class="line-wrap">
				<span class="left-line"></span>
				<h3 class="title" style="<?php echo esc_attr( implode( '; ', $title_style ) ); ?>"><?php echo esc_html($title); ?></h3>
				<span class="right-line"></span>
			</div>

		</div>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'yanka_addons_title', 'yanka_shortcode_title' );
}
