<?php

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'yanka_shortcode_image_preview' ) ) {
	function yanka_shortcode_image_preview( $atts, $content = null ) {
		$output = $title = $description = $images_preview = $image_preview = $el_class = $css = '';

		extract( shortcode_atts( array(
			'images_preview'        => '',
			'css_animation'            => '',
			'el_class'            => '',
			'css' 				  => '',
		), $atts ) );

        $rd_number = rand();

		$classes = array('preview-layout pt-grid-col-6');

		if ( ! empty( $el_class ) ) {
			$classes[] = esc_attr($el_class);
		}


		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		$images_url = vc_param_group_parse_atts($atts['images_preview']);

        ob_start(); ?>
        <div class="preview-layout-wrapper">
	        <div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" >
					<?php
					foreach($images_url as $image_url) {
						$link_preview = '';
						$title_preview = '';				
						$_img = wp_get_attachment_image_src($image_url['image_preview'], 'full');
						$img = $_img[0];
						?>

						<div class="element-item">
							<?php 
								if (isset($image_url['link_preview']) && $image_url['link_preview'] !==''){ $link_preview = esc_attr($image_url['link_preview']);}
								if (isset($image_url['title_preview']) && $image_url['title_preview'] !==''){ $title_preview = esc_attr($image_url['title_preview']);}
							?>

							<a href="<?php echo $link_preview; ?>" class="preview-layout" target="_blank">
								<figure>
									<img src="<?php echo esc_url( $img ); ?>" data-src="<?php echo esc_url( $img ); ?>" alt="<?php echo $title_preview; ?>" data-was-processed="true" class="lazyload loaded">
									<figcaption><?php echo $title_preview; ?></figcaption>
								</figure>
							</a>
						</div>
						<?php
					}
					?>
	        </div>
        </div>
		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'yanka_images_preview', 'yanka_shortcode_image_preview' );
}
