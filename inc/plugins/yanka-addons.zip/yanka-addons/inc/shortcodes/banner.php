<?php

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'yanka_shortcode_banner' ) ) {
	function yanka_shortcode_banner( $atts, $content = null ) {
		$output = $title = $title_size = $title_color = $banner_style = $title_google_fonts = $subtitle = $subtitle_size = $image = $pr_promo_type = $box_align = $el_class = $subtitle_style = $title_style = $css = '';

		extract( shortcode_atts( array(
			'image'                    		=> '',
			'pr_promo_type'                 => '',
			'content_form'                  => '',
			'title'                    		=> '',
			'subtitle'                 		=> '',
			'subsubtitle'            		=> '',
			'link'                     		=> '',
			'content_hidden'				=> '1',
			'hover_effect'					=> '1',
			'padding_content'				=> '',
			'content_width' 		   		=> '100',
			'banner_style'			  		=> '',
			'title_font_family'               		=> '',
			'title_size'               		=> '',
			'title_type'               		=> '',
			'title_spacing'            		=> '',
			'title_margin'            		=> '',
			'title_weight'         	   		=> 'default',
			'title_color'              		=> '',
			'title_use_theme_fonts'    		=> '',
			'title_google_fonts'       		=> '',
			'subtitle_font_family'          => '',
			'subtitle_size'            		=> '',
			'subtitle_type'            		=> '',
			'subtitle_spacing'         		=> '',
			'subtitle_margin'         		=> '',
			'subtitle_weight'          		=> 'default',
			'subtitle_color'           		=> '',
			'subtitle_use_theme_fonts' 		=> '',
			'subtitle_google_fonts'    		=> '',
			'subsubtitle_font_family'            	=> '',
			'subsubtitle_size'            	=> '',
			'subsubtitle_type'            	=> '',
			'subsubtitle_spacing'         	=> '',
			'subsubtitle_margin'         	=> '',
			'subsubtitle_weight'          	=> 'default',
			'subsubtitle_color'           	=> '',
			'subsubtitle_use_theme_fonts' 	=> '',
			'subsubtitle_google_fonts'    	=> '',
			'btn_text' 						=> '',
			'btn_link' 		 				=> '',
			'btn_font_family'            			=> '',
			'btn_size'            			=> '',
			'btn_type'            			=> '',
			'btn_spacing'         			=> '',
			'btn_margin'         			=> '',
			'btn_weight'          			=> 'default',
			'btn_use_theme_fonts' 			=> '',
			'btn_color' 					=> '',
			'btn_bgcolor' 					=> '',
			'btn_bdcolor' 					=> '',
			'btn_color_hover' 				=> '',
			'btn_bgcolor_hover' 			=> '',
			'btn_bdcolor_hover' 			=> '',
			'btn_padding_top' 				=> '',
			'btn_padding_right' 			=> '',
			'btn_padding_bottom' 			=> '',
			'btn_padding_left' 				=> '',
			'btn_border_top' 				=> '1',
			'btn_border_left' 				=> '1',
			'btn_border_bottom' 			=> '1',
			'btn_border_right' 				=> '1',
			'btn_border_radius' 			=> '',
			'btn_use_theme_fonts' 			=> '',
			'btn_google_fonts'    			=> '',
			'css_animation'            		=> '',
			'box_align'                		=> '',
			'vertical_alignment'	   		=> '',
			'el_class'                 		=> '',
			'css'                      		=> ''
		), $atts ) );

		$classes = array( 'banner-box pr oh' );

		if ( ! empty( $el_class ) ) {
			$classes[] = esc_attr($el_class);
		}

		if ( isset( $content_hidden ) && $content_hidden == 'yes' ) {
			$classes[] = 'box-content-hidden';
		}

		if ( ! empty( $hover_effect ) ) {
			$classes[] = 'box-effect image-effect-' . esc_attr($hover_effect);
		}

		if ( !empty( $vertical_alignment ) ) {
			$classes[] = 'banner-vertical-' . esc_attr($vertical_alignment);
		}

		if ( !empty( $banner_style ) ) {
			$classes[] = 'banner-' . esc_attr($banner_style);
		}


		if ( ! empty( $css ) ) {
            $classes[] = vc_shortcode_custom_css_class( $css, ' ' );
        }

		if( isset( $animation ) && $animation != '' ) {
			$classes[] = 'shortcodeAnimation';
		}

		if ( '' !== $css_animation ) {
			$classes[] = getCSSAnimation( $css_animation );
		}

		// box content
		$textwrap_class = array();

		if ( isset( $box_align ) ) {
			$textwrap_class[] = esc_attr($box_align);
		}
		
		if ( ! empty( $pr_promo_type ) ) {
			$textwrap_class[] = 'pr-promo-type' . esc_attr($pr_promo_type);
		} else {
			$textwrap_class[] = 'pr-promo-type';
		}
		
		$banner_text_padding = array();

		if ( '' !== $padding_content && is_numeric($padding_content)) {
			$banner_text_padding[] = 'padding: '. esc_attr($padding_content)/16 .'em';
		}

		$google_fonts_obj = new Vc_Google_Fonts();
		$google_fonts_field_settings = isset( $google_fonts_field['settings'], $google_fonts_field['settings']['fields'] ) ? $google_fonts_field['settings']['fields'] : array();

		// Title style
		$title_class = array();

		if ( '' !== $title_type ) {
			$title_class[] = 'type-title-'.$title_type;
		}

		if ( isset($title_font_family) && '' !== $title_font_family ) {
			$title_class[] = esc_attr($title_font_family) . '-font';
		}

		$title_style_parent = array();

		if ( '' !== $title_margin && is_numeric($title_margin) ) {
			$title_style_parent[] = 'margin-top: '. esc_attr($title_margin)/16 .'em';
		}


		$title_style = array();

		if ( '' !== $title_size && is_numeric($title_size)) {
			$title_style[] = 'font-size: '. esc_attr($title_size)/16 .'em';
		}

		if ( '' !== $title_color ) {
			$title_style[] = 'color: '. $title_color;
		}

		if ( '' !== $title_spacing && is_numeric($title_spacing) ) {
			$title_style[] = 'letter-spacing: '. esc_attr($title_spacing)/16 .'em';
		}

		if ( '' !== $title_weight && 'default' !== $title_weight ) {
			$title_style[] = 'font-weight: '. esc_attr($title_weight);
		}


		// Subtitle style

		$subtitle_class = array();

		if ( '' !== $subtitle_type ) {
			$subtitle_class[] = 'type-title-'.$subtitle_type;
		}

		if ( isset($subtitle_font_family) && '' !== $subtitle_font_family ) {
			$subtitle_class[] = esc_attr($subtitle_font_family) . '-font';
		}

		$subtitle_style_parent = array();

		if ( '' !== $subtitle_margin && is_numeric($subtitle_margin) ) {
			$subtitle_style_parent[] = 'margin-top: '. esc_attr($subtitle_margin)/16 .'em';
		}

		$subtitle_style = array();

		if ( '' !== $subtitle_size && is_numeric($subtitle_size)) {
			$subtitle_style[] = 'font-size: '. esc_attr($subtitle_size)/16 .'em';
		}

		if ( '' !== $subtitle_color ) {
			$subtitle_style[] = 'color: '. $subtitle_color;
		}

		if ( '' !== $subtitle_spacing && is_numeric($subtitle_spacing) ) {
			$subtitle_style[] = 'letter-spacing: '. esc_attr($subtitle_spacing)/16 .'em';
		}

		if ( '' !== $subtitle_weight && 'default' !== $subtitle_weight ) {
			$subtitle_style[] = 'font-weight: '. esc_attr($subtitle_weight);
		}

		// SubSubtitle style

		$subsubtitle_class = array();

		if ( '' !== $subsubtitle_type ) {
			$subsubtitle_class[] = 'type-title-'.$subsubtitle_type;
		}

		if ( isset($subsubtitle_font_family) && '' !== $subsubtitle_font_family ) {
			$subsubtitle_class[] = esc_attr($subsubtitle_font_family) . '-font';
		}

		$subsubtitle_style_parent = array();

		if ( '' !== $subsubtitle_margin && is_numeric($subsubtitle_margin) ) {
			$subsubtitle_style_parent[] = 'margin-top: '. esc_attr($subsubtitle_margin)/16 .'em';
		}


		$subsubtitle_style = array();

		if ( '' !== $subsubtitle_size && is_numeric($subsubtitle_size)) {
			$subsubtitle_style[] = 'font-size: '. esc_attr($subsubtitle_size)/16 .'em';
		}

		if ( '' !== $subsubtitle_color ) {
			$subsubtitle_style[] = 'color: '. $subsubtitle_color;
		}

		if ( '' !== $subsubtitle_spacing && is_numeric($subsubtitle_spacing)) {
			$subsubtitle_style[] = 'letter-spacing: '. esc_attr($subsubtitle_spacing)/16 .'em';
		}

		if ( '' !== $subsubtitle_weight && 'default' !== $subsubtitle_weight ) {
			$subsubtitle_style[] = 'font-weight: '. esc_attr($subsubtitle_weight);
		}

		// Button style

		
		$button_class = array();
		//pr-promo-type

		if ( isset($btn_color) && '' !== $btn_color ) {
			$button_class[] = 'button-color-'. esc_attr($btn_color);
		}

		if ( isset($btn_bgcolor) && '' !== $btn_bgcolor ) {
			$button_class[] = 'background-color-'. esc_attr($btn_bgcolor);
		}

		if ( isset($btn_bdcolor) && '' !== $btn_bdcolor ) {
			$button_class[] = 'border-color-'. esc_attr($btn_bdcolor);
		}

		if ( isset($btn_color_hover) && '' !== $btn_color_hover ) {
			$button_class[] = 'button-color-hover-'. esc_attr($btn_color_hover);
		}

		if ( isset($btn_bgcolor_hover) && '' !== $btn_bgcolor_hover ) {
			$button_class[] = 'background-color-hover-'. esc_attr($btn_bgcolor_hover);
		}

		if ( isset($btn_bdcolor_hover) && '' !== $btn_bdcolor_hover ) {
			$button_class[] = 'border-color-hover-'. esc_attr($btn_bdcolor_hover);
		}

		if ( isset($btn_font_family) && '' !== $btn_font_family ) {
			$button_class[] = esc_attr($btn_font_family) . '-font';
		}

		$btn_style_parent = array();

		if ( '' !== $btn_margin && is_numeric($btn_margin) ) {
			$btn_style_parent[] = 'margin-top: '. esc_attr($btn_margin)/16 .'em';
		}


		$btn_style = array();

		$btn_google_fonts_data = strlen( $btn_google_fonts ) > 0 ? $google_fonts_obj->_vc_google_fonts_parse_attributes( $google_fonts_field_settings, $btn_google_fonts ) : '';

		if ( ( ! isset( $btn_use_theme_fonts ) || 'yes' !== $btn_use_theme_fonts ) && ! empty( $btn_google_fonts_data ) && isset( $btn_google_fonts_data['values'], $btn_google_fonts_data['values']['font_family'], $btn_google_fonts_data['values']['font_style'] ) ) {
			$btn_google_fonts_family = explode( ':', $btn_google_fonts_data['values']['font_family'] );
			$btn_style[] = 'font-family:' . $btn_google_fonts_family[0];
			$btn_google_fonts_styles = explode( ':', $btn_google_fonts_data['values']['font_style'] );
			$btn_style[] = 'font-weight:' . $btn_google_fonts_styles[1];
			$btn_style[] = 'font-style:' . $btn_google_fonts_styles[2];
		}

		if ( '' !== $btn_size && is_numeric($btn_size)) {
			$btn_style[] = 'font-size: '. esc_attr($btn_size)/16 .'em';
		}

		if ( '' !== $btn_spacing && is_numeric($btn_spacing)) {
			$btn_style[] = 'letter-spacing: '. esc_attr($btn_spacing)/16 .'em';
		}

		if ( '' !== $btn_weight && 'default' !== $btn_weight ) {
			$btn_style[] = 'font-weight: '. esc_attr($btn_weight);
		}

		if ( '' !== $btn_border_top && is_numeric($btn_border_top) ) {
			$btn_style[] = 'border-top: '. esc_attr($btn_border_top) .'px solid';
		}

		if ( '' !== $btn_border_right && is_numeric($btn_border_right) ) {
			$btn_style[] = 'border-right: '. esc_attr($btn_border_right) .'px solid';
		}

		if ( '' !== $btn_border_bottom && is_numeric($btn_border_bottom) ) {
			$btn_style[] = 'border-bottom: '. esc_attr($btn_border_bottom) .'px solid';
		}

		if ( '' !== $btn_border_left && is_numeric($btn_border_left) ) {
			$btn_style[] = 'border-left: '. esc_attr($btn_border_left) .'px solid';
		}

		if ( '' !== $btn_border_radius && is_numeric($btn_border_radius) ) {
			$btn_style[] = 'border-radius: '. esc_attr($btn_border_radius) .'px';
		}

		if ( '' !== $btn_padding_top && is_numeric($btn_padding_top) ) {
			$btn_style[] = 'padding-top: '. esc_attr($btn_padding_top) .'px';
		}

		if ( '' !== $btn_padding_right && is_numeric($btn_padding_right) ) {
			$btn_style[] = 'padding-right: '. esc_attr($btn_padding_right) .'px';
		}

		if ( '' !== $btn_padding_bottom && is_numeric($btn_padding_bottom) ) {
			$btn_style[] = 'padding-bottom: '. esc_attr($btn_padding_bottom) .'px';
		}

		if ( '' !== $btn_padding_left && is_numeric($btn_padding_left) ) {
			$btn_style[] = 'padding-left: '. esc_attr($btn_padding_left) .'px';
		}


		// Link
		$onclick = '';
		if ( ! empty( $link ) ) {
			$banner_url = vc_build_link( $link );
			$onclick = 'onclick="window.location.href=\''. esc_url( $banner_url['url'] ).'\'"';
		}

		$allowed_html = array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'span' => array(
				'class' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		);

		ob_start(); ?>

		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" <?php echo '' . $onclick; ?> >
			<?php if ( ! empty($image) ): ?>
				<div class="banner-image item-effect">
					<?php
					    $img_id = preg_replace( '/[^\d]/', '', $image );
					    $image  = wpb_getImageBySize( array( 'attach_id' => $img_id ) );
					?>
					<img src="<?php echo esc_url( $image['p_img_large'][0] ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
				</div>
			<?php endif; ?>
			<?php if ( $content_form == '1'){ ?>
				<?php if ( !empty($title) || !empty($subtitle) || !empty($subsubtitle) || !empty($btn_text) ) : ?>
			        <div class="banner-text <?php echo esc_attr( implode( ' ', $textwrap_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $banner_text_padding ) ); ?>">
			            <div class="banner-inner content-width-<?php echo esc_attr( $content_width ); ?>">
			            	<div class="content-background"></div>
			                <div class="content">
								<?php if ( !empty($title) ) : ?>
									<div class="title <?php echo esc_attr( implode( ' ', $title_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $title_style_parent ) ); ?>">
										<p style="<?php echo esc_attr( implode( '; ', $title_style ) ); ?>"><?php echo wp_kses($title, $allowed_html); ?></p>
									</div>
								<?php endif; ?>

								<?php if ( !empty($subtitle) ) : ?>
									<div class="subtitle <?php echo esc_attr( implode( ' ', $subtitle_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $subtitle_style_parent ) ); ?>">
										<p style="<?php echo esc_attr( implode( '; ', $subtitle_style ) ); ?>"><?php echo wp_kses($subtitle, $allowed_html); ?></p>
									</div>
								<?php endif; ?>

								<?php if ( !empty($subsubtitle) ) : ?>
									<div class="subsubtitle <?php echo esc_attr( implode( ' ', $subsubtitle_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $subsubtitle_style_parent ) ); ?>">
										<p style="<?php echo esc_attr( implode( '; ', $subsubtitle_style ) ); ?>"><?php echo wp_kses($subsubtitle, $allowed_html); ?></p>
									</div>
								<?php endif; ?>

								<?php if( ! empty( $btn_text ) ) : ?>
									<div class="button-banner-wrapper <?php echo esc_attr( implode( ' ', $button_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $btn_style_parent ) ); ?>">
										<a href="<?php echo esc_url($btn_link); ?>" style="<?php echo esc_attr( implode( '; ', $btn_style ) ); ?>" class="button-banner"><?php echo esc_html($btn_text); ?></a>
									</div>
								<?php endif; ?>
			                </div>
			            </div>
			        </div>
			    <?php endif; ?>
			<?php }else{ ?>
				<div class="banner-text <?php echo esc_attr( implode( ' ', $textwrap_class ) ); ?>" style="<?php echo esc_attr( implode( '; ', $banner_text_padding ) ); ?>">
		            <div class="banner-inner">
		            	<div class="content-background"></div>
		                <div class="content">
		                	<?php echo do_shortcode( $content ); ?>
		                </div>
		            </div>
			    </div>
			<?php } ?>
		</div>

		<?php
		$output = ob_get_contents();
		ob_end_clean();

		return $output;
	}
	add_shortcode( 'yanka_addons_banner', 'yanka_shortcode_banner' );
}
