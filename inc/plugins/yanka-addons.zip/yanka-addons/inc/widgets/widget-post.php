<?php
/**
 * Widget API: Yanka_Recent_Products class
 */

class Yanka_Recent_Products extends WP_Widget {

	/**
	 * Sets up a new Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'widget_recent_post_with_image',
			'description'                 => __( 'Your site&#8217;s most recent Category Product.', 'yanka' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'recent-posts-with-image', __( 'JMS - Recent Category Product', 'yanka' ), $widget_ops );
		$this->alt_option_name = 'widget_recent_post_with_image';
	}

	/**
	 * Outputs the content for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$title = ( ! empty( $instance['title'] ) ) ? esc_attr($instance['title']) : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		$kwtax = isset( $instance['kwtax'] ) ? $instance['kwtax'] : 'uncategorized';

		/**
		 * Filters the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */

		?>
		<?php echo ''.$args['before_widget']; ?>
		<?php if ( $title ) {
			echo ''.$args['before_title'] . esc_attr( $title ) . $args['after_title'];
		} ?>

		<?php
			$parent_cat_arg = array('term_taxonomy_id' => $kwtax, 'hide_empty' => false, 'parent' => 0);
			$parent_cat = get_terms('product_cat',$parent_cat_arg); //List category		
			foreach ($parent_cat as $catVal) {
				
				$term_link = get_term_link( $catVal );


			    $child_arg = array( 'hide_empty' => false, 'parent' => $catVal->term_id );

			    $child_cat = get_terms( 'product_cat', $child_arg );
			    $count_child_cat = count($child_cat);

			    echo '<div class="category-block"><div class="row"><ul>';
					$i = 0;
			        foreach( $child_cat as $child_term ) {
						$term = get_term_link( $child_term );
						$i++;
						if($i <= $count_child_cat) { ?>
			            <li class="col-4 has-child">
			            	<a class="item" href="<?php echo esc_url( $term ); ?>">
			            		<?php echo $child_term->name; ?>
			            	</a>
			            </li>
						<?php } ?>
			    <?php }

			    echo '</ul></div></div><div class="clearfix"></div>';
				}
			?>
		<?php echo ''.$args['after_widget']; ?>
		<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();
	}

	/**
	 * Handles updating the settings for the current Recent Posts widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['kwtax'] = strip_tags( $new_instance['kwtax'] );
		return $instance;
	}

	/**
	 * Outputs the settings form for the Recent Posts widget.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$kwtax     = isset( $instance['kwtax'] ) ? esc_attr( $instance['kwtax'] ) : '';

?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php _e( 'Title:', 'yanka' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>
		<p>
	        <select id="<?php echo $this->get_field_id('kwtax'); ?>" name="<?php echo $this->get_field_name('kwtax'); ?>" class="widefat" style="width:100%;">
	            <?php foreach(get_terms('product_cat','parent=0&hide_empty=0') as $term) { ?>
	            	<option <?php selected(esc_attr($kwtax), $term->term_id ); ?> value="<?php echo $term->term_id; ?>"><?php echo $term->name; ?></option>
	            <?php } ?>      
	        </select>
    	</p>
<?php
	}
}

function yanka_register_widget_recent_products() {
	register_widget( 'Yanka_Recent_Products' );
}
add_action( 'widgets_init', 'yanka_register_widget_recent_products' );
?>
