<?php
/**
* ------------------------------------------------------------------------------------------------
* yanka product tab shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_product_tabs' ) ) {
	function yanka_vc_map_product_tabs() {
		vc_map( array(
			'name'                    => esc_html__( 'Product Tabs', 'yanka' ),
			'description' 			  => esc_html__( 'Product tabs for your marketplace', 'yanka' ),
			'base'                    => 'jms_product_tabs',
			'as_parent'               => array('only' => 'jms_product_tab'),
			'content_element'         => true,
			'show_settings_on_create' => true,
    		'icon'                    => 'jms-icon',
			'category'                => esc_html__( 'JMS Addons', 'yanka' ),
			'params'                  => array(
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Title', 'yanka' ),
					'param_name' => 'title'
				),
				array(
                    'type'       => 'dropdown',
                    'heading'    => esc_html__( 'Line Bottom', 'yanka-addons' ),
                    'param_name' => 'line_bottom',
                    'value'      => array(
                        esc_html__( 'Big line under ', 'yanka-addons' )        => 'big',
                        esc_html__( 'Small line under', 'yanka-addons' )       => 'small',
                        esc_html__( 'Big line on the right', 'yanka-addons' )  => 'right',
                        esc_html__( 'None', 'yanka-addons' )                   => 'none',
                    ),
                ),

				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Align', 'yanka' ),
					'param_name' => 'title_style',
					'save_always' => true,
					'value'      => array(
						esc_html__( 'Aligned Line', 'yanka' ) => 'line',
						esc_html__( 'Aligned Left', 'yanka' ) => 'left',
						esc_html__( 'Aligned Center', 'yanka' ) => 'center',
						esc_html__( 'Aligned Right', 'yanka' ) => 'right',
					),
					'std'	=> ''
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Title color', 'yanka-addons' ),
					'param_name' => 'color',
					'value'      => array(
						esc_html__( 'Default', 'yanka-addons' )           => 'default',
						esc_html__( 'Primary color', 'yanka-addons' )     => 'primary',
						esc_html__( 'Black', 'yanka-addons' )             => 'black',
						esc_html__( 'White', 'yanka-addons' )             => 'white',
					)
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Title size', 'yanka-addons' ),
					'param_name' => 'size',
					'value'      => array(
						esc_html__( 'Small', 'yanka-addons' )       => 'small',
						esc_html__( 'Medium', 'yanka-addons' )      => 'medium',
						esc_html__( 'Large', 'yanka-addons' )       => 'large',
						esc_html__( 'Extra Large', 'yanka-addons' ) => 'extra-large'
					),
					'std'	=> 'large'
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'yanka' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka' )
				),
				array(
					'type'        	=> 'css_editor',
					'heading'     	=> esc_html__( 'Css', 'yanka' ),
					'param_name'  	=> 'css',
					'group'       	=> esc_html__( 'Design options', 'yanka' ),
					'admin_label' 	=> false,
				),
			),
		    'js_view' => 'VcColumnView'
		) );

		$yanka_products_params = vc_map_integrate_shortcode( yanka_get_products_shortcode_map_params(), '', '', array(
		    'exclude' => array(
		   ),
		  ) );

		vc_map( array(
			'name'            => esc_html__( 'Product tab', 'yanka' ),
			'base'            => 'jms_product_tab',
			'class'           => '',
			'as_child'        => array('only' => 'jms_product_tabs'),
			'content_element' => true,
            'icon'            => 'jms-icon',
			'category'        => esc_html__( 'JMS Addons', 'yanka' ),
			'params' 		  => array_merge( array(
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Title for the tab', 'yanka' ),
					'param_name' => 'title',
					'value'      => '',
				),
			), $yanka_products_params )
		) );

    }
    add_action( 'vc_before_init', 'yanka_vc_map_product_tabs' );
}

