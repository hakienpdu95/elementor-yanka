<?php
/**
* ------------------------------------------------------------------------------------------------
* Custom title shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_title' ) ) {
	function yanka_vc_map_title() {
        vc_map(
            array(
                'name'        => esc_html__( 'Custom Title', 'yanka-addons' ),
                'base'        => 'yanka_addons_title',
                'icon'        => 'jms-icon',
                'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
                'params'      => array(
                    array(
                        'param_name'  => 'title',
                        'heading'     => esc_html__( 'Title', 'yanka-addons' ),
                        'type'        => 'textfield',
                        'edit_field_class' => 'vc_col-sm-4 vc_column vc_padding_custom',
                        'value'       => 'Custom Title',
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Font Family', 'yanka-addons' ),
                        'param_name' => 'title_font_family',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )   => '',
                            esc_html__( 'Font Primary', 'yanka-addons' )   => 'primary',
                            esc_html__( 'Font Second', 'yanka-addons' ) => 'second',
                        ),
                    ),
                    array(
                        'param_name'  => 'title_type',
                        'heading'     => esc_html__('Title Type', 'yanka-addons'),
                        'type'       => 'dropdown',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'save_always' => true,
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons')                      => '',
                            esc_html__( 'Background Opacity White', 'yanka-addons')     => '1',
                            esc_html__( 'Background Opacity Black', 'yanka-addons')     => '2',
                            esc_html__( 'Border bottom', 'yanka-addons')                => '3',
                        ),
                    ),
                    array(
                        'param_name'  => 'title_size',
                        'heading'     => esc_html__('Font Size (px)', 'yanka-addons'),
                        'type'        => 'textfield',
                        'edit_field_class' => 'vc_col-sm-2 vc_column',
                        'save_always' => true,
                        'description' => esc_html__('Select the font size of the title.', 'yanka-addons') ,
                        'value'       => '',
                    ),
                    array(
                        'param_name'  => 'title_line_height',
                        'heading'     => esc_html__('Line Height (px)', 'yanka-addons'),
                        'type'        => 'textfield',
                        'edit_field_class' => 'vc_col-sm-2 vc_column',
                        'value'       => '',
                    ),                    
                    array(
                        'param_name'  => 'title_spacing',
                        'heading'     => esc_html__('Letter Spacing (px)', 'yanka-addons'),
                        'type'        => 'textfield',
                        'edit_field_class' => 'vc_col-sm-2 vc_column',
                        'value'       => '',
                    ),
                    array(
                        'param_name'  => 'title_margin',
                        'heading'     => esc_html__('Margin Bottom (px)', 'yanka-addons'),
                        'type'        => 'textfield',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'       => '',
                    ),
                    array(
                        'param_name'  => 'title_weight',
                        'heading'     => esc_html__('Font Weight', 'yanka-addons'),
                        'type'       => 'dropdown',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'save_always' => true,
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons')  => '',
                            esc_html__( 'Light', 'yanka-addons')    => '300',
                            esc_html__( 'Regular', 'yanka-addons')  => '400',
                            esc_html__( 'Medium', 'yanka-addons')   => '500',
                            esc_html__( 'Semibold', 'yanka-addons') => '600',
                            esc_html__( 'Bold', 'yanka-addons')     => '700',
                            esc_html__( 'Extra Bold', 'yanka-addons')     => '800',
                            esc_html__( 'Black', 'yanka-addons')     => '900',
                        ),
                    ),

                    array(
                        'param_name' => 'title_align',
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Align', 'yanka-addons' ),
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )   => '',
                            esc_html__( 'Left', 'yanka-addons' )   => 'left',
                            esc_html__( 'Center', 'yanka-addons' ) => 'center',
                            esc_html__( 'Right', 'yanka-addons' )  => 'right',
                        ),
                        'std'        => 'center',
                    ),

                    array(
                        'param_name' => 'title_width',
                        'type'       => 'textfield',
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                        'heading'    => esc_html__( 'Width(%)', 'yanka-addons' ),
                        'value'      => '',
                    ),

                    array(
                        'param_name'  => 'title_color',
                        'heading'     => esc_html__('Title Color', 'yanka-addons'),
                        'type'        => 'colorpicker',
                    ),
                    array(
                        'param_name' => 'title_use_theme_fonts',
                        'type'       => 'checkbox',
                        'heading'    => esc_html__( 'Use theme default font family?', 'yanka-addons' ),
                        'std'        => 'yes',
                        'value'      => array(
                            esc_html__( 'Yes', 'yanka-addons' ) => 'yes'
                        ),
                        'description' => esc_html__( 'Use font family for title.', 'yanka-addons' ),
                    ),
                    array(
                        'param_name' => 'title_google_fonts',
                        'type'       => 'google_fonts',
                        'value'      => 'font_family:Abril%20Fatface%3Aregular|font_style:400%20regular%3A400%3Anormal',
                        'settings'   => array(
                            'fields' => array(
                                'font_family_description' => esc_html__( 'Select font family.', 'yanka-addons' ),
                                'font_style_description'  => esc_html__( 'Select font styling.', 'yanka-addons' ),
                            ),
                        ),
                        'dependency' => array(
                            'element'            => 'title_use_theme_fonts',
                            'value_not_equal_to' => 'yes',
                        ),
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'param_name'  => 'el_class',
                        'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
                        'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'yanka-addons' ),
                        'type' 	      => 'textfield',
                    ),
                    array(
                        'type'       => 'css_editor',
                        'heading'    => esc_html__( 'CSS', 'yanka-addons' ),
                        'param_name' => 'css',
                        'group'      => esc_html__( 'Design options', 'yanka-addons' ),
                    ),
                )
            )
        );
    }
    add_action( 'vc_before_init', 'yanka_vc_map_title' );
}
