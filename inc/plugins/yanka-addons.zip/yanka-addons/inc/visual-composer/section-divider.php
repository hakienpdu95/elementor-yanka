<?php
/**
* ------------------------------------------------------------------------------------------------
* Section divider element map
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_row_divider' ) ) {
	function yanka_vc_map_row_divider() {
		vc_map( array(
			'name'     => esc_html__( 'Section divider', 'yanka-addons'),
			'base'     => 'yanka_divider',
            'icon'     => 'jms-icon',
            'category' => esc_html__( 'JMS Addons', 'yanka-addons' ),
			'params'   => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Position', 'yanka-addons' ),
					'param_name' => 'position',
                    'admin_label' => true,
					'value'      => array(
						esc_html__( 'Top', 'yanka-addons' )    => 'top',
						esc_html__( 'Bottom', 'yanka-addons' ) => 'bottom'
					)
				),
				array(
					'type'       => 'checkbox',
					'heading'    => esc_html__( 'Overlap', 'yanka-addons' ),
					'param_name' => 'content_overlap',
					'value'      => array( esc_html__( 'Enable', 'yanka-addons' ) => 'enable' )
				),
				array(
					'type'       => 'colorpicker',
					'heading'    => esc_html__( 'Color', 'yanka-addons' ),
					'param_name' => 'color',
                    'admin_label' => true,
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Style', 'yanka-addons' ),
					'param_name' => 'style',
                    'admin_label' => true,
					'value'      => array(
						esc_html__( 'Waves Small', 'yanka-addons' )    => 'waves-small',
						esc_html__( 'Waves Wide', 'yanka-addons' )     => 'waves-wide',
                        esc_html__( 'Circle', 'yanka-addons' )         => 'circle',
                        esc_html__( 'Triangle', 'yanka-addons' )       => 'triangle',
						esc_html__( 'Clouds', 'yanka-addons' )         => 'clouds',
					)
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Custom height', 'yanka-addons' ),
					'param_name' => 'custom_height',
					'dependency' => array(
						'element' => 'style',
						'value'   => array( 'curved-line', 'diagonal-right', 'half-circle', 'diagonal-left' )
					),
					'description' => esc_html__( 'Enter divider height (Note: CSS measurement units allowed).', 'yanka-addons' )
				),

				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' )
				),
			),
		) );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_row_divider' );
}
