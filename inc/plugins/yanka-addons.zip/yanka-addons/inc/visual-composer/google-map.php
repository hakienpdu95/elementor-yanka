<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka google maps shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_google_map' ) ) {
	function yanka_vc_map_google_map() {
        vc_map( array(
			'name'              => esc_html__( 'Google Map', 'yanka-addons' ),
			'base'              => 'google_map',
            'category'          => esc_html__( 'JMS Addons', 'yanka-addons' ),
            'icon'              => 'jms-icon',
			'params'            => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Latitude (required)', 'yanka-addons' ),
					'param_name' => 'lat',
					'description' => wp_kses( __('You can use <a href="http://universimmedia.pagesperso-orange.fr/geo/loc.htm" target="_blank">this service</a> to get coordinates of your location.', 'yanka-addons'), array(
                        'a' => array(
                            'href' => array(),
                            'target' => array()
                        )
                    ) )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Longitude (required)', 'yanka-addons' ),
					'param_name' => 'lon'
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Google API key (required)', 'yanka-addons' ),
					'param_name' => 'google_key',
					'description' => wp_kses( __('Obtain API key <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">here</a> to use our Google Map VC element.', 'yanka-addons'), array(
                        'a' => array(
                            'href' => array(),
                            'target' => array()
                        )
                    ) )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Zoom', 'yanka-addons' ),
					'param_name' => 'zoom',
					'description' => esc_html__('Zoom level when focus the marker 0 - 19', 'yanka-addons'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Height', 'yanka-addons' ),
					'param_name' => 'height',
					'description' => esc_html__('Default: 400', 'yanka-addons')
				),
				array(
					'type' => 'textarea_raw_html',
					'heading' => esc_html__( 'Styles (JSON)', 'yanka-addons' ),
					'param_name' => 'style_json',
					'description' => wp_kses( __('Styled maps allow you to customize the presentation of the standard Google base maps, changing the visual display of such elements as roads, parks, and built-up areas.<br>
You can find more Google Maps styles on the website: <a target="_blank" href="http://snazzymaps.com/">Snazzy Maps</a>Just copy JSON code and paste it here.', 'yanka-addons'), array(
                        'a' => array(
                            'href' => array(),
                            'target' => array()
                        )
                    ) )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Zoom with mouse wheel', 'yanka-addons' ),
					'param_name' => 'scroll',
					'value' => array(
						'' => '',
						esc_html__( 'Yes', 'yanka-addons' ) => 'yes',
						esc_html__( 'No', 'yanka-addons' ) => 'no',
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Content on the map vertical position', 'yanka-addons' ),
					'param_name' => 'content_vertical',
					'value' => array(
						'' => '',
						esc_html__( 'Top', 'yanka-addons' ) => 'top',
						esc_html__( 'Middle', 'yanka-addons' ) => 'middle',
						esc_html__( 'Bottom', 'yanka-addons' ) => 'bottom',
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Content on the map horizontal position', 'yanka-addons' ),
					'param_name' => 'content_horizontal',
					'value'      => array(
						'' => '',
						esc_html__( 'Left', 'yanka-addons' ) => 'left',
						esc_html__( 'Center', 'yanka-addons' ) => 'center',
						esc_html__( 'Right', 'yanka-addons' ) => 'right',
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Content width', 'yanka-addons' ),
					'param_name'  => 'content_width',
					'description' => esc_html__('Default: 300', 'yanka-addons')
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' )
				)
			),
		));
	}
	add_action( 'vc_before_init', 'yanka_vc_map_google_map' );
}
