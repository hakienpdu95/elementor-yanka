<?php
/**
* ------------------------------------------------------------------------------------------------
* Categories element map
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_product_categories' ) ) {
    function yanka_vc_map_product_categories() {
        $order_by_values = array(
            '',
            esc_html__( 'Date', 'yanka' )                           => 'date',
            esc_html__( 'ID', 'yanka' )                             => 'ID',
            esc_html__( 'Author', 'yanka' )                         => 'author',
            esc_html__( 'Title', 'yanka' )                          => 'title',
            esc_html__( 'Modified', 'yanka' )                       => 'modified',
            esc_html__( 'Comment count', 'yanka' )                  => 'comment_count',
            esc_html__( 'Menu order', 'yanka' )                     => 'menu_order',
            esc_html__( 'As IDs or slugs provided order', 'yanka' ) => 'include',
        );

        $order_way_values = array(
            '',
            esc_html__( 'Descending', 'yanka' ) => 'DESC',
            esc_html__( 'Ascending', 'yanka' )  => 'ASC',
        );

        vc_map( array(
            'name'     => esc_html__( 'Feature categories', 'yanka' ),
            'base'     => 'jms_product_categories',
            'icon'     => 'jms-icon',
            'category' => esc_html__( 'JMS Addons', 'yanka' ),
            'params'   => array(
                array(
                    'param_name' => 'categories_design',
                    'heading'    => esc_html__( 'Design', 'yanka' ),
                    'type'       => 'dropdown',
                    'value'      => array(
                        esc_html__( 'Grid', 'yanka' )     => 'grid',
                        esc_html__( 'Carousel', 'yanka' ) => 'carousel',
                    ),
                    'admin_label' => true,
                    'save_always' => true,
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Columns', 'yanka' ),
                    'param_name'  => 'columns',
                    'save_always' => true,
                    'value'       => array(
                        6,5,4,3,2,1
                    ),
                    'std'         => '4',
                    'admin_label' => true,
                    'description' => esc_html__( 'The `columns` field is used to display the columns of categories.', 'yanka' ),
                    'dependency'  => array(
                        'element' => 'categories_design',
                        'value'   => 'grid'
                    ),
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Order by', 'yanka' ),
                    'param_name'  => 'orderby',
                    'value'       => $order_by_values,
                    'save_always' => true,
                    'description' => sprintf( wp_kses(  __( 'Select how to sort retrieved categories. More at %s.', 'yanka' ), array(
                            'a' => array(
                                'href'   => array(),
                                'target' => array()
                            )
                        )), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Sort order', 'yanka' ),
                    'param_name'  => 'order',
                    'value'       => $order_way_values,
                    'save_always' => true,
                    'description' => sprintf( wp_kses(  __( 'Designates the ascending or descending order. More at %s.', 'yanka' ), array(
                            'a' => array(
                                'href' => array(),
                                'target' => array()
                            )
                        )), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
                ),
                array(
                    'param_name'  => 'spacing',
                    'heading'     => esc_html__( 'Product spacing', 'yanka' ),
                    'type'        => 'dropdown',
                    'std'         => 30,
                    'save_always' => true,
                    'value'       => array(
                        40,30,20,10,0
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'grid'
                    ),
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__( 'Hide empty', 'yanka' ),
                    'param_name' => 'hide_empty',
                    'value' => array( esc_html__( 'Yes, please', 'yanka' ) => 'yes' ),
                    'std'         => 'yes',
                ),
                array(
                    'type' => 'autocomplete',
                    'heading' => esc_html__( 'Categories', 'yanka' ),
                    'param_name' => 'ids',
                    'settings' => array(
                        'multiple' => true,
                        'sortable' => true,
                    ),
                    'save_always' => true,
                    'admin_label' => true,
                    'description' => esc_html__( 'List of product categories', 'yanka' ),
                ),
                array(
                    'param_name'  => 'hover_effect',
                    'heading'     => esc_html__( 'Hover Effect', 'yanka-addons' ),
                    'type'        => 'dropdown',
                    'description' => esc_html__( 'Please consult link: ("your-domain"/banners) to choose effect.', 'yanka-addons' ),
                    'save_always' => true,
                    'value'       => array(
                        esc_html__( 'Effect 1', 'yanka-addons' )        => '1',
                        esc_html__( 'Effect 2', 'yanka-addons' )        => '2',
                        esc_html__( 'Effect 3', 'yanka-addons' )        => '3',
                        esc_html__( 'Effect 4', 'yanka-addons' )        => '4',
                        esc_html__( 'Effect 5', 'yanka-addons' )        => '5',
                        esc_html__( 'Effect 6', 'yanka-addons' )        => '6',
                        esc_html__( 'Effect 7', 'yanka-addons' )        => '7',
                        esc_html__( 'Effect 8', 'yanka-addons' )        => '8',
                        esc_html__( 'Effect 9', 'yanka-addons' )        => '9',
                        esc_html__( 'Effect 10', 'yanka-addons' )       => '10',
                        esc_html__( 'Effect 11', 'yanka-addons' )       => '11',
                        esc_html__( 'Effect 12', 'yanka-addons' )       => '12',
                        esc_html__( 'Effect 13', 'yanka-addons' )       => '13',
                        esc_html__( 'Effect 14', 'yanka-addons' )       => '14',
                        esc_html__( 'Effect 15', 'yanka-addons' )       => '15',
                        esc_html__( 'Effect 16', 'yanka-addons' )       => '16',
                        esc_html__( 'Effect 17', 'yanka-addons' )       => '17',
                        esc_html__( 'Disable', 'yanka-addons' )         => 'none',
                    ),
                ),
                vc_map_add_css_animation(),
                array(
                    'param_name'  => 'el_class',
                    'heading'     => esc_html__( 'Extra class name', 'yanka' ),
                    'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka' ),
                    'type'        => 'textfield',
                    'admin_label' => false,
                ),
                // SLIDER SETTINGS
                array(
                    'param_name'  => 'items_desktop',
                    'heading'     => esc_html__( 'Items Show On Desktop', 'yanka' ),
                    'description' => esc_html__( 'Show number of items on desktop', 'yanka'),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 4,
                    'value'       => array(
                        esc_html__( '1 Item', 'yanka' ) => 1,
                        esc_html__( '2 Items', 'yanka' ) => 2,
                        esc_html__( '3 Items', 'yanka' ) => 3,
                        esc_html__( '4 Items', 'yanka' ) => 4,
                        esc_html__( '5 Items', 'yanka' ) => 5,
                        esc_html__( '6 Items', 'yanka' ) => 6,
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                 array(
                    'param_name'  => 'items_small_desktop',
                    'heading'     => esc_html__( 'Items Show On Small Desktop', 'yanka' ),
                    'description' => esc_html__( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'yanka'),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 4,
                    'value'       => array(
                        esc_html__( '1 Item', 'yanka' )  => 1,
                        esc_html__( '2 Items', 'yanka' ) => 2,
                        esc_html__( '3 Items', 'yanka' ) => 3,
                        esc_html__( '4 Items', 'yanka' ) => 4,
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                 array(
                    'param_name'  => 'items_tablet',
                    'heading'     => esc_html__( 'Items Show On Tablet Device', 'yanka' ),
                    'description' => esc_html__( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'yanka'),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 3,
                    'value'       => array(
                        esc_html__( '1 Item', 'yanka' ) => 1,
                        esc_html__( '2 Items', 'yanka' ) => 2,
                        esc_html__( '3 Items', 'yanka' ) => 3,
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                 array(
                    'param_name'  => 'items_mobile',
                    'heading'     => esc_html__( 'Items Show On Mobile Device', 'yanka' ),
                    'description' => esc_html__( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'yanka'),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 2,
                    'value'       => array(
                        esc_html__( '1 Item', 'yanka' ) => 1,
                        esc_html__( '2 Items', 'yanka' ) => 2,
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                 array(
                    'param_name'  => 'items_small_mobile',
                    'heading'     => esc_html__( 'Items Show On Small Mobile Device', 'yanka' ),
                    'description' => esc_html__( 'Show number of items on small mobile. Screen resolution of device < 445px.', 'yanka'),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 1,
                    'value'       => array(
                        esc_html__( '1 Item', 'yanka' ) => 1,
                        esc_html__( '2 Items', 'yanka' ) => 2,
                    ),
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                array(
                    'param_name' => 'navigation',
                    'heading'    => esc_html__( 'Enable Navigation', 'yanka' ),
                    'type'       => 'checkbox',
                    'group'      => esc_html__( 'Slider Settings', 'yanka' ),
                    'value'      => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
                    'std'        => 'yes',
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                array(
                    'param_name'  => 'style_navigation',
                    'heading'     => esc_html__( 'Arrow Styles', 'yanka' ),
                    'type'        => 'dropdown',
                    'group'       => esc_html__( 'Slider Settings', 'yanka' ),
                    'std'         => 'icon_arrow',
                    'value'       => array(
                        esc_html__( 'Icon Arrow', 'yanka' ) => 'icon_arrow',
                        esc_html__( 'Icon Arrow Box', 'yanka' ) => 'icon_box_arrow',
                    ),
                    'dependency' => array(
                        'element' => 'navigation',
                        'value'   => 'yes'
                    ),
                ),
                array(
                    'param_name' => 'pagination',
                    'heading'    => esc_html__( 'Enable Dots Pagination', 'yanka' ),
                    'type'       => 'checkbox',
                    'group'      => esc_html__( 'Slider Settings', 'yanka' ),
                    'value'      => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
                    'std'        => 'no',
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                 array(
                    'param_name'    => 'autoplay',
                    'heading'       => esc_html__( 'Autoplay', 'yanka' ),
                    'description'   => esc_html__( 'Enables autoplay mode', 'yanka' ),
                    'type'          => 'checkbox',
                    'group'         => esc_html__( 'Slider Settings', 'yanka' ),
                    'value'         => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
                    'std'           => 'no',
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                array(
                    'param_name'    => 'loop',
                    'heading'       => esc_html__( 'Loop', 'yanka' ),
                    'description'   => esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'yanka' ),
                    'type'          => 'checkbox',
                    'group'         => esc_html__( 'Slider Settings', 'yanka' ),
                    'value'         => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
                    'std'           => 'no',
                    'dependency' => array(
                        'element' => 'categories_design',
                        'value'   => 'carousel'
                    ),
                ),
                array(
                    'type'          => 'css_editor',
                    'heading'       => esc_html__( 'Css', 'yanka' ),
                    'param_name'    => 'css',
                    'group'         => esc_html__( 'Design options', 'yanka' ),
                    'admin_label'   => false,
                )
            )
        ) );
    }
    add_action( 'vc_before_init', 'yanka_vc_map_product_categories' );
}

//Filters For autocomplete param:
//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback
add_filter( 'vc_autocomplete_jms_product_categories_ids_callback', 'yanka_productCategoryCategoryAutocompleteSuggester', 10, 1 ); // Get suggestion(find). Must return an array
add_filter( 'vc_autocomplete_jms_product_categories_ids_render', 'yanka_productCategoryCategoryAutocompleteSuggester', 10, 1 );

if( ! function_exists( 'yanka_productCategoryCategoryAutocompleteSuggester' ) ) {
    function yanka_productCategoryCategoryAutocompleteSuggester( $query, $slug = false ) {
        global $wpdb;
        $cat_id = (int) $query;
        $query = trim( $query );
        $post_meta_infos = $wpdb->get_results(
            $wpdb->prepare( "SELECT a.term_id AS id, b.name as name, b.slug AS slug
                        FROM {$wpdb->term_taxonomy} AS a
                        INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
                        WHERE a.taxonomy = 'product_cat' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )",
                $cat_id > 0 ? $cat_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

        $result = array();
        if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
            foreach ( $post_meta_infos as $value ) {
                $data = array();
                $data['value'] = $slug ? $value['slug'] : $value['id'];
                $data['label'] = esc_html__( 'Id', 'yanka' ) . ': ' .
                                 $value['id'] .
                                 ( ( strlen( $value['name'] ) > 0 ) ? ' - ' . esc_html__( 'Name', 'yanka' ) . ': ' .
                                                                      $value['name'] : '' ) .
                                 ( ( strlen( $value['slug'] ) > 0 ) ? ' - ' . esc_html__( 'Slug', 'yanka' ) . ': ' .
                                                                      $value['slug'] : '' );
                $result[] = $data;
            }
        }

        return $result;
    }
}
if( ! function_exists( 'yanka_productCategoryCategoryRenderByIdExact' ) ) {
    function yanka_productCategoryCategoryRenderByIdExact( $query ) {
        global $wpdb;
        $query = $query['value'];
        $cat_id = (int) $query;
        $term = get_term( $cat_id, 'product_cat' );

        return yanka_productCategoryTermOutput( $term );
    }
}

if( ! function_exists( 'yanka_productCategoryTermOutput' ) ) {
    function yanka_productCategoryTermOutput( $term ) {
        $term_slug = $term->slug;
        $term_title = $term->name;
        $term_id = $term->term_id;

        $term_slug_display = '';
        if ( ! empty( $term_sku ) ) {
            $term_slug_display = ' - ' . esc_html__( 'Sku', 'yanka' ) . ': ' . $term_slug;
        }

        $term_title_display = '';
        if ( ! empty( $product_title ) ) {
            $term_title_display = ' - ' . esc_html__( 'Title', 'yanka' ) . ': ' . $term_title;
        }

        $term_id_display = esc_html__( 'Id', 'yanka' ) . ': ' . $term_id;

        $data = array();
        $data['value'] = $term_id;
        $data['label'] = $term_id_display . $term_title_display . $term_slug_display;

        return ! empty( $data ) ? $data : false;
    }
}
