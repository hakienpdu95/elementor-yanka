<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka instagram shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_instagram' ) ) {
	function yanka_vc_map_instagram() {
        vc_map(
     		array(
     			'name'     => esc_html__( 'Instagram', 'yanka-addons' ),
     			'base'     => 'yanka_addons_instagram',
     			'icon'     => 'jms-icon',
     			'category' => esc_html__( 'JMS Addons', 'yanka-addons' ),
     			'params'   => array(
     				array(
     					'param_name'  => 'user_id',
     					'heading'     => esc_html__( 'User ID', 'yanka-addons' ),
     					'description' => sprintf( wp_kses_post( 'Lookup User ID <a target="_blank" href="%s">here</a>', 'yanka-addons' ), 'https://smashballoon.com/instagram-feed/find-instagram-user-id/' ),
     					'type'        => 'textfield',
     					'admin_label' => true,
     				),
     				array(
     					'param_name'  => 'access_token',
     					'heading'     => esc_html__( 'Access Token', 'yanka-addons' ),
     					'description' => sprintf( wp_kses_post( 'Lookup Access Token <a target="_blank" href="%s">here</a>', 'yanka-addons' ), 'http://instagram.pixelunion.net/' ),
     					'type'        => 'textfield',
     					'admin_label' => true,
     				),
     				array(
     					'param_name' => 'slider',
     					'heading'    => esc_html__( 'Enable Slider', 'yanka-addons' ),
     					'type'       => 'dropdown',
     					'std'        => 'no',
     					'admin_label' => true,
     					'save_always' => true,
     					'value'      => array(
     						esc_html__( 'No', 'yanka-addons' )  => 'no',
     						esc_html__( 'Yes', 'yanka-addons' ) => 'yes',
     					)
     				),
     				array(
     					'param_name'  => 'limit',
     					'heading'     => esc_html__( 'Per Page', 'yanka-addons' ),
     					'description' => esc_html__( 'How much items per page to show', 'yanka-addons' ),
     					'type'        => 'textfield',
     					'value'       => 6,
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'no'
     					),
     				),
     				array(
     					'param_name'  => 'columns',
     					'heading'     => esc_html__( 'Columns', 'yanka-addons' ),
     					'description' => esc_html__( 'This parameter is not working if slider has enabled', 'yanka-addons' ),
     					'type'        => 'dropdown',
     					'value'       => array(
     						esc_html__( '2 columns', 'yanka-addons' ) => 2,
     						esc_html__( '3 columns', 'yanka-addons' ) => 3,
     						esc_html__( '4 columns', 'yanka-addons' ) => 4,
     						esc_html__( '5 columns', 'yanka-addons' ) => 5,
     						esc_html__( '6 columns', 'yanka-addons' ) => 6,
                            esc_html__( '7 columns', 'yanka-addons' ) => 7,
                            esc_html__( '8 columns', 'yanka-addons' ) => 8,
                            esc_html__( '9 columns', 'yanka-addons' ) => 9
     					),
     					'save_always' => true,
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'no'
     					),
     				),
     				array(
     					'param_name' => 'gutter',
     					'heading'    => esc_html__( 'Gutter Width', 'yanka-addons' ),
     					'type'       => 'dropdown',
     					'save_always' => true,
     					'value'      => array(
     						'0px'  => '0',
     						'10px'  => '10',
     						'20px'  => '20',
     						'30px'  => '30',
     						'40px'  => '40',
     					)
     				),
     				array(
     					'type'       => 'checkbox',
     					'heading'    => esc_html__( 'Rounded corners for images', 'yanka-addons' ),
     					'param_name' => 'rounded',
     					'value'      => array( esc_html__( 'Yes, please', 'yanka-addons' ) => 1 )
     				),
                    vc_map_add_css_animation(),
     				array(
     					'param_name'  => 'el_class',
     					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
     					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' ),
     					'type'        => 'textfield',
                         'admin_label' => false,
     				),
     				array(
     					'param_name'  => 'items_desktop',
     					'heading'     => esc_html__( 'Items Show On Desktop', 'yanka-addons' ),
                         'description' => esc_html__( 'Show number of items on desktop', 'yanka-addons'),
     					'type'        => 'dropdown',
                         'group'       => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'std'         => 6,
     					'save_always' => true,
                         'value'       => array(
             				esc_html__( '1 Item', 'yanka-addons' ) => 1,
             				esc_html__( '2 Items', 'yanka-addons' ) => 2,
             				esc_html__( '3 Items', 'yanka-addons' ) => 3,
             				esc_html__( '4 Items', 'yanka-addons' ) => 4,
             				esc_html__( '5 Items', 'yanka-addons' ) => 5,
                             esc_html__( '6 Items', 'yanka-addons' ) => 6
             			),
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
                     array(
     					'param_name'  => 'items_small_desktop',
     					'heading'     => esc_html__( 'Items Show On Small Desktop', 'yanka-addons' ),
                         'description' => esc_html__( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'yanka-addons'),
                         'type'        => 'dropdown',
                         'group'       => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'std'         => 4,
     					'save_always' => true,
                         'value'       => array(
     						esc_html__( '1 Item', 'yanka-addons' ) => 1,
             				esc_html__( '2 Items', 'yanka-addons' ) => 2,
             				esc_html__( '3 Items', 'yanka-addons' ) => 3,
             				esc_html__( '4 Items', 'yanka-addons' ) => 4,
             				esc_html__( '5 Items', 'yanka-addons' ) => 5,
             			),
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
                     array(
     					'param_name'  => 'items_tablet',
     					'heading'     => esc_html__( 'Items Show On Tablet Device', 'yanka-addons' ),
     					'description' => esc_html__( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'yanka-addons'),
                         'type'        => 'dropdown',
                         'group'       => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'std'         => 3,
     					'save_always' => true,
                         'value'       => array(
     						esc_html__( '1 Item', 'yanka-addons' ) => 1,
             				esc_html__( '2 Items', 'yanka-addons' ) => 2,
             				esc_html__( '3 Items', 'yanka-addons' ) => 3,
             				esc_html__( '4 Items', 'yanka-addons' ) => 4,
             			),
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
                     array(
     					'param_name'  => 'items_mobile',
     					'heading'     => esc_html__( 'Items Show On Mobile Device', 'yanka-addons' ),
     					'description' => esc_html__( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'yanka-addons'),
                         'type'        => 'dropdown',
                         'group'       => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'std'         => 2,
     					'save_always' => true,
                         'value'       => array(
             				esc_html__( '1 Item', 'yanka-addons' )  => 1,
             				esc_html__( '2 Items', 'yanka-addons' ) => 2,
     						esc_html__( '2 Items', 'yanka-addons' ) => 3
             			),
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
                     array(
     					'param_name'  => 'items_small_mobile',
     					'heading'     => esc_html__( 'Items Show On Small Mobile Device', 'yanka-addons' ),
     					'description' => esc_html__( 'Show number of items on small mobile. Screen resolution of device < 445px.', 'yanka-addons'),
                         'type'        => 'dropdown',
                         'group'       => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'std'         => 2,
     					'save_always' => true,
                         'value'       => array(
             				esc_html__( '1 Item', 'yanka-addons' ) => 1,
             				esc_html__( '2 Items', 'yanka-addons' ) => 2,
             			),
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
     				array(
     					'param_name' => 'navigation',
     					'heading'    => esc_html__( 'Enable Navigation', 'yanka-addons' ),
     					'type'       => 'checkbox',
                         'group'      => esc_html__( 'Slider Settings', 'yanka-addons' ),
                         'value'      => array( esc_html__( 'Yes', 'yanka-addons' ) => 'yes' ),
     					'std'        => 'yes',
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
     				array(
     					'param_name' => 'pagination',
     					'heading'    => esc_html__( 'Enable Dots Pagination', 'yanka-addons' ),
     					'type'       => 'checkbox',
                         'group'      => esc_html__( 'Slider Settings', 'yanka-addons' ),
     					'value'      => array( esc_html__( 'Yes', 'yanka-addons' ) => 'yes' ),
     					'std'        => 'no',
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
     				),
                     array(
                         'param_name'  	=> 'autoplay',
                         'heading'     	=> esc_html__( 'Autoplay', 'yanka-addons' ),
             			'description' 	=> esc_html__( 'Enables autoplay mode', 'yanka-addons' ),
             			'type'        	=> 'checkbox',
             			'group'         => esc_html__( 'Slider Settings', 'yanka-addons' ),
     					'value'      	=> array( esc_html__( 'Yes', 'yanka-addons' ) => 'yes' ),
     					'std'        	=> 'no',
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
             		),
             		array(
                         'param_name'  	=> 'loop',
             			'heading'     	=> esc_html__( 'Loop', 'yanka-addons' ),
                         'description' 	=> esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'yanka-addons' ),
                         'type'        	=> 'checkbox',
                         'group'         => esc_html__( 'Slider Settings', 'yanka-addons' ),
             			'value'       	=> array( esc_html__( 'Yes', 'yanka-addons' ) => 'yes' ),
     					'std'        	=> 'no',
     					'dependency' => array(
     						'element' => 'slider',
     						'value'   => 'yes'
     					),
             		),
     				array(
     		            'type'        	=> 'css_editor',
     		            'heading'     	=> esc_html__( 'Css', 'yanka-addons' ),
     		            'param_name'  	=> 'css',
     		            'group'       	=> esc_html__( 'Design options', 'yanka-addons' ),
     		            'admin_label' 	=> false,
     				),
     			)
     		)
     	);
	}
	add_action( 'vc_before_init', 'yanka_vc_map_instagram' );
}
