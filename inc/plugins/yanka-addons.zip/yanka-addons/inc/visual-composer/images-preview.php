<?php
/**
* ------------------------------------------------------------------------------------------------
* Adiva brands preview shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_images_preview' ) ) {
	function yanka_vc_map_images_preview() {
        vc_map(
     		array(
     			'name'        => esc_html__( 'Image Preview Grid', 'yanka-addons' ),
     			'description' => esc_html__( 'Display image preview layout grid.', 'yanka-addons' ),
     			'base'        => 'yanka_images_preview',
     			'icon'        => 'jms-icon',
     			'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
     			'params'      => array(
                    array(
                        'param_name' => 'images_preview',
                        'type' => 'param_group',
                        'heading'     => esc_html__( 'Image Item', 'yanka-addons' ),
                        'description' => esc_html__( 'Click (Toggle row) arrow to show content item', 'yanka-addons'),
                        'params' => array(
                            array(
                                'param_name' => 'image_preview',
                                'type' => 'attach_image',
                                'name' => 'label',
                                'heading' => __('Image', 'yanka-addons'),
                            ),
                            array(
                                'param_name' => 'link_preview',
                                'type' => 'textfield',
                                'name' => 'content',
                                'heading' => __('Link', 'yanka-addons'),
                            ),
                            array(
                                'param_name' => 'title_preview',
                                'type' => 'textfield',
                                'name' => 'content_title',
                                'heading' => __('Title', 'yanka-addons'),
                            )                                                                                    
                        )

                    ),                    
                    vc_map_add_css_animation(),
     				array(
     					'param_name'  => 'el_class',
     					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
     					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' ),
     					'type'        => 'textfield',
                         'admin_label' => false,
     				),
     				array(
     		            'type'        	=> 'css_editor',
     		            'heading'     	=> esc_html__( 'Css', 'yanka-addons' ),
     		            'param_name'  	=> 'css',
     		            'group'       	=> esc_html__( 'Design options', 'yanka-addons' ),
     		            'admin_label' 	=> false,
     				),
     			)
     		)
     	);
	}
	add_action( 'vc_before_init', 'yanka_vc_map_images_preview' );
}
