<?php
/**
* ------------------------------------------------------------------------------------------------
* Images gallery element map
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_gallery' ) ) {
	function yanka_vc_map_gallery() {
		vc_map( array(
			'name'        => esc_html__( 'Images gallery', 'yanka-addons' ),
			'base'        => 'jms_gallery',
			'description' => esc_html__( 'Images grid/masonry', 'yanka-addons' ),
            'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
            'icon'        => 'jms-icon',
			'params'      => array(
				array(
					'type'        => 'attach_images',
					'heading'     => esc_html__( 'Images', 'yanka-addons' ),
					'param_name'  => 'images',
					'admin_label' => true,
					'value'       => '',
					'description' => esc_html__( 'Select images from media library.', 'yanka-addons' )
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Image size', 'yanka-addons' ),
					'param_name'  => 'img_size',
					'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "full" size.', 'yanka-addons' )
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'View', 'yanka-addons' ),
					'param_name'  => 'gallery_type',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'Default grid', 'yanka-addons' ) => 'grid',
						esc_html__( 'Masonry grid', 'yanka-addons' ) => 'masonry',
					)
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Space between images', 'yanka-addons' ),
					'param_name' => 'spacing',
					'std'        => '10',
					'value'      => array(
						0, 10, 20, 30, 40
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Columns', 'yanka-addons' ),
					'value'       => 3,
					'param_name'  => 'columns',
					'save_always' => true,
					'description' => esc_html__( 'How much columns grid', 'yanka-addons' ),
					'value' => array(
						'1' => 1,
						'2' => 2,
						'3' => 3,
						'4' => 4,
						'5' => 5,
						'6' => 6,
					),
					'dependency' => array(
						'element' => 'gallery_type',
						'value'   => array( 'grid', 'masonry' ),
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'On click action', 'yanka-addons' ),
					'param_name' => 'on_click',
					'value'      => array(
						''                                   => '',
						esc_html__( 'Lightbox', 'yanka-addons' )    => 'lightbox',
						esc_html__( 'None', 'yanka-addons' )        => 'none'
					)
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Open in new tab', 'yanka-addons' ),
					'save_always' => true,
					'param_name'  => 'target_blank',
					'value'       => array( esc_html__( 'Yes, please', 'yanka-addons' ) => 'yes' ),
					'default'     => 'yes',
					'dependency' => array(
						'element' => 'on_click',
						'value'   => array( 'links' ),
					),
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' )
				),
			)
		) );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_gallery' );
}
