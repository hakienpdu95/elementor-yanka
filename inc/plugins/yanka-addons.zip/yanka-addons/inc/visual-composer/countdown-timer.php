<?php
/**
* ------------------------------------------------------------------------------------------------
* Countdown timer element map
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_countdown_timer' ) ) {
	function yanka_vc_map_countdown_timer() {
		vc_map( array(
			'name'        => esc_html__( 'Countdown timer', 'yanka-addons' ),
			'base'        => 'yanka_countdown',
            'icon'        => 'jms-icon',
            'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
            'description' => esc_html__( 'Shows countdown timer', 'yanka-addons' ),
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Date', 'yanka-addons' ),
					'param_name'  => 'date',
					'description' => esc_html__( 'Final date in the format Y/m/d. For example 2018/03/12', 'yanka-addons' )
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Color Scheme', 'yanka-addons' ),
					'param_name' => 'color_scheme',
					'value'      => array(
						esc_html__( 'Choose', 'yanka-addons' ) => '',
						esc_html__( 'Light', 'yanka-addons' )  => 'light',
						esc_html__( 'Dark', 'yanka-addons' )   => 'dark',
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Size', 'yanka-addons' ),
					'param_name' => 'size',
					'value'      => array(
						''                                   => '',
						esc_html__( 'Small', 'yanka-addons' )       => 'small',
						esc_html__( 'Medium', 'yanka-addons' )      => 'medium',
						esc_html__( 'Large', 'yanka-addons' )       => 'large',
						esc_html__( 'Extra Large', 'yanka-addons' ) => 'xlarge',
					)
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Align', 'yanka-addons' ),
					'param_name' => 'align',
					'value'      => array(
						'' => '',
						esc_html__( 'left', 'yanka-addons' )   => 'left',
						esc_html__( 'center', 'yanka-addons' ) => 'center',
						esc_html__( 'right', 'yanka-addons' )  => 'right',
					)
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Style', 'yanka-addons' ),
					'param_name' => 'style',
					'value'      => array(
						'' => '',
						esc_html__( 'Standard', 'yanka-addons' )      => 'standard',
						esc_html__( 'Transparent', 'yanka-addons' )   => 'transparent',
						esc_html__( 'Primary color', 'yanka-addons' ) => 'primary',
					)
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' )
				)
			)
		) );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_countdown_timer' );
}
