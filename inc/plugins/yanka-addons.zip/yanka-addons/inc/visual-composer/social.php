<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka social icons shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_social_icons' ) ) {
	function yanka_vc_map_social_icons() {
        vc_map(
            array(
                'name'        => esc_html__( 'Social icons', 'yanka-addons' ),
                'base'        => 'yanka_social_icons',
                'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
                'icon'        => 'jms-icon',
                'params'      => array(
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Title Social', 'yanka-addons' ),
                        'param_name' => 'title_social',
                    ),                    
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Facebook link', 'yanka-addons' ),
                        'param_name' => 'facebook',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Twitter link', 'yanka-addons' ),
                        'param_name' => 'twitter',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Google+ link', 'yanka-addons' ),
                        'param_name' => 'google_plus',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Linkedin link', 'yanka-addons' ),
                        'param_name' => 'linkedin',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Skype link', 'yanka-addons' ),
                        'param_name' => 'skype',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Instagram link', 'yanka-addons' ),
                        'param_name' => 'instagram',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Pinterest link', 'yanka-addons' ),
                        'param_name' => 'pinterest',
                    ),                    
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Align', 'yanka-addons' ),
                        'param_name' => 'align',
                        'value'      => array(
                            esc_html__( 'Left', 'yanka-addons' )   => 'left',
                            esc_html__( 'Center', 'yanka-addons' ) => 'center',
                            esc_html__( 'Right', 'yanka-addons' )  => 'right',
                        ),
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Style', 'yanka-addons' ),
                        'param_name' => 'style',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )    => 'default',
                            esc_html__( 'Icon', 'yanka-addons' ) => 'icon',
                            esc_html__( 'Background', 'yanka-addons' ) => 'icon-background',
                            esc_html__( 'Background circle', 'yanka-addons' ) => 'icon-background-circle',
                            esc_html__( 'Border', 'yanka-addons' ) => 'icon-background-border',
                        ),
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Social size', 'yanka-addons' ),
                        'param_name' => 'size',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' ) => '',
                            esc_html__( 'Small', 'yanka-addons' )   => 'small',
                            esc_html__( 'Medium', 'yanka-addons' )   => 'medium',
                            esc_html__( 'Large', 'yanka-addons' )   => 'large',
                        ),
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Color', 'yanka-addons' ),
                        'param_name' => 'color',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )    => 'default',
                            esc_html__( 'Blạck', 'yanka-addons' ) => 'black',
                            esc_html__( 'White', 'yanka-addons' ) => 'white',
                            esc_html__( 'Primary color', 'yanka-addons' ) => 'primary',
                        ),
                        'admin_label' => true,
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Extra class name', 'mazza-core' ),
                        'param_name'  => 'el_class',
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'mazza-core' )
                    )
                ),
            )
        );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_social_icons' );
}
