<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka megamenu shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_megamenu' ) ) {
	function yanka_vc_map_megamenu() {
        vc_map(
            array(
                'name'        => esc_html__( 'Mega Menu Widget', 'yanka-addons' ),
                'base'        => 'yanka_megamenu',
                'description' => esc_html__( 'Categories mega menu widget', 'yanka-addons' ),
                'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
                'icon'        => 'jms-icon',
                'params'      => array(
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Title', 'yanka-addons' ),
                        'param_name' => 'title',
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Choose Menu', 'yanka-addons' ),
                        'param_name' => 'nav_menu',
                        'value'      => yanka_get_menus_array(),
                        'admin_label' => true,
                    ),
                    array(
                        'type'       => 'colorpicker',
                        'heading'    => esc_html__( 'Title Color', 'yanka-addons' ),
                        'param_name' => 'color',
                        'admin_label' => true,
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'param_name'  => 'el_class',
                        'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' ),
                        'type'        => 'textfield',
                        'admin_label' => false,
                    ),
                    array(
                        'type'        	=> 'css_editor',
                        'heading'     	=> esc_html__( 'Css', 'yanka-addons' ),
                        'param_name'  	=> 'css',
                        'group'       	=> esc_html__( 'Design options', 'yanka-addons' ),
                        'admin_label' 	=> false,
                    ),
                ),
            )
        );

	}
	add_action( 'vc_before_init', 'yanka_vc_map_megamenu' );
}

// Get menu array()
if( ! function_exists( 'yanka_get_menus_array') ) {
	function yanka_get_menus_array() {
		$yanka_menus = wp_get_nav_menus();
		$yanka_menu_dropdown = array();

		foreach ( $yanka_menus as $menu ) {
			$yanka_menu_dropdown[$menu->term_id] = $menu->name;
		}

		return $yanka_menu_dropdown;
	}
}
