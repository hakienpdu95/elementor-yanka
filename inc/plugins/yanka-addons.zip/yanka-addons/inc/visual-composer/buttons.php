<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka button shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_buttons' ) ) {
	function yanka_vc_map_buttons() {
        vc_map(
            array(
                'name'        => esc_html__( 'Button', 'yanka-addons' ),
                'base'        => 'yanka_buttons',
                'icon'        => 'jms-icon',
                'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
                'params'      => array(
                    array(
                        'param_name' => 'title',
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Title', 'yanka-addons' ),
                        'value'      => 'Button',
                        'admin_label' => true
                    ),
                    array(
                        'param_name' => 'link',
                        'type'       => 'vc_link',
                        'heading'    => esc_html__( 'Link', 'yanka-addons' ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Font Family', 'yanka-addons' ),
                        'param_name' => 'font_family_button',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )   => '',
                            esc_html__( 'Font Primary', 'yanka-addons' )   => 'primary',
                            esc_html__( 'Font Second', 'yanka-addons' ) => 'second',
                        ),
                    ),
                    array(
                        'param_name' => 'size_button',
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Font Size (px)', 'yanka-addons' ),
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value'      => '',
                    ),
                    array(
                        'param_name' => 'spacing_button',
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Letter spacing (px)', 'yanka-addons' ),
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value'      => '',
                    ),
                    array(
                        'param_name'  => 'weight_button',
                        'type'       => 'dropdown',
                        'heading'     => esc_html__('Font Weight', 'yanka-addons'),
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'save_always' => true,
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons')  => '',
                            esc_html__( 'Light', 'yanka-addons')    => '300',
                            esc_html__( 'Regular', 'yanka-addons')  => '400',
                            esc_html__( 'Medium', 'yanka-addons')   => '500',
                            esc_html__( 'Semibold', 'yanka-addons') => '600',
                            esc_html__( 'Bold', 'yanka-addons')     => '700',
                            esc_html__( 'Extra Bold', 'yanka-addons')     => '800',
                            esc_html__( 'Black', 'yanka-addons')     => '900',                             
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Color', 'yanka-addons' ),
                        'param_name' => 'color_button',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Text Body Color', 'yanka-addons' ) => 'text-body',
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'description' => __( 'Select single bar background color.', 'yanka-addons' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Background Color', 'yanka-addons' ),
                        'param_name' => 'bgcolor_button',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Text Body Color', 'yanka-addons' ) => 'text-body',
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'description' => __( 'Select single bar background color.', 'yanka-addons' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Border Color', 'yanka-addons' ),
                        'param_name' => 'bdcolor_button',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Text Body Color', 'yanka-addons' ) => 'text-body',
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'description' => __( 'Select single bar background color.', 'yanka-addons' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Padding top (px)', 'yanka-addons' ),
                        'param_name' => 'padding_top',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '10',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Padding right (px)', 'yanka-addons' ),
                        'param_name' => 'padding_right',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '30',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Padding bottom (px)', 'yanka-addons' ),
                        'param_name' => 'padding_bottom',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '10',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Padding left (px)', 'yanka-addons' ),
                        'param_name' => 'padding_left',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '30',
                    ),
                    
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Border top (px)', 'yanka-addons' ),
                        'param_name' => 'border_top',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '1',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Border right (px)', 'yanka-addons' ),
                        'param_name' => 'border_right',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '1',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Border bottom (px)', 'yanka-addons' ),
                        'param_name' => 'border_bottom',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '1',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Border left (px)', 'yanka-addons' ),
                        'param_name' => 'border_left',
                        'edit_field_class' => 'vc_col-sm-3 vc_column',
                        'value'      => '1',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Border Radius (%)', 'yanka-addons' ),
                        'param_name' => 'border_radius',
                        'value'      => '1',
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Align', 'yanka-addons' ),
                        'param_name' => 'align',
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )   => '',
                            esc_html__( 'Left', 'yanka-addons' )   => 'left',
                            esc_html__( 'Center', 'yanka-addons' ) => 'center',
                            esc_html__( 'Right', 'yanka-addons' )  => 'right',
                        ),
                        'dependency'  => array(
                            'element'            => 'button_inline',
                            'value_not_equal_to' => array( 'yes' ),
                        ),
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'param_name'  => 'el_class',
                        'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
                        'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'yanka-addons' ),
                        'type' 	      => 'textfield',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Color', 'yanka-addons' ),
                        'param_name' => 'color_button_hover',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'group'         => esc_html__( 'Button Hover', 'yanka-addons' ),
                        'param_holder_class' => 'vc_colored-dropdown vc_padding_custom',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Background Color', 'yanka-addons' ),
                        'param_name' => 'bgcolor_button_hover',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'group'         => esc_html__( 'Button Hover', 'yanka-addons' ),                        'param_holder_class' => 'vc_colored-dropdown',
                    ),
                    array(
                        'type' => 'dropdown',
                        'heading' => __( 'Border Color', 'yanka-addons' ),
                        'param_name' => 'bdcolor_button_hover',
                        'edit_field_class' => 'vc_col-sm-4 vc_column',
                        'value' => array(
                                __( 'Default', 'yanka-addons' ) => '',
                            )  + getVcShared( 'colors-dashed' ) + array(
                                __( 'Primary Color', 'yanka-addons' ) => 'primary',
                            ),
                        'group'         => esc_html__( 'Button Hover', 'yanka-addons' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                    ),
                    array(
                        'type'          => 'css_editor',
                        'heading'       => esc_html__( 'Css', 'yanka-addons' ),
                        'param_name'    => 'css',
                        'group'         => esc_html__( 'Design options', 'yanka-addons' ),
                    ),
                )
            )
        );
    }
    add_action( 'vc_before_init', 'yanka_vc_map_buttons' );
}
