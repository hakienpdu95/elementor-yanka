<?php
/**
* ------------------------------------------------------------------------------------------------
* Yanka team member shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_team_member' ) ) {
	function yanka_vc_map_team_member() {
        vc_map(
            array(
                'name'        => esc_html__( 'Team Member', 'yanka-addons' ),
                'base'        => 'team_member',
                'category'    => esc_html__( 'JMS Addons', 'yanka-addons' ),
                'description' => esc_html__( 'Display information about some person', 'yanka-addons' ),
                'icon'        => 'jms-icon',
                'params'      => array(
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Name', 'yanka-addons' ),
                        'param_name'  => 'name',
                        'value'       => '',
                        'description' => esc_html__( 'User name', 'yanka-addons' )
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Title', 'yanka-addons' ),
                        'param_name'  => 'position',
                        'value'       => '',
                        'description' => esc_html__( 'User title', 'yanka-addons' )
                    ),
                    array(
                        'type'        => 'attach_image',
                        'heading'     => esc_html__( 'User Avatar', 'yanka-addons' ),
                        'param_name'  => 'image',
                        'value'       => '',
                        'description' => esc_html__( 'Select image from media library.', 'yanka-addons' )
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Image size', 'yanka-addons' ),
                        'param_name'  => 'img_size',
                        'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'yanka-addons' )
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Align', 'yanka-addons' ),
                        'param_name' => 'align',
                        'value'      => array(
                            esc_html__( 'Left', 'yanka-addons' )   => 'left',
                            esc_html__( 'Center', 'yanka-addons' ) => 'center',
                            esc_html__( 'Right', 'yanka-addons' )  => 'right',
                        ),
                    ),
                    array(
                        'type'          => 'dropdown',
                        'heading'       => esc_html__( 'Color Scheme', 'yanka-addons' ),
                        'param_name'    => 'yanka_color_scheme',
                        'value'         => array(
                            esc_html__( 'choose', 'yanka-addons' ) => '',
                            esc_html__( 'Light', 'yanka-addons' )  => 'light',
                            esc_html__( 'Dark', 'yanka-addons' )   => 'dark',
                        ),
                    ),
                    array(
                        'type'        => 'textarea_html',
                        'heading'     => esc_html__( 'Text', 'yanka-addons' ),
                        'param_name'  => 'content',
                        'description' => esc_html__( 'You can add some member bio here.', 'yanka-addons' )
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Facebook link', 'yanka-addons' ),
                        'param_name' => 'facebook',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Twitter link', 'yanka-addons' ),
                        'param_name' => 'twitter',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Google+ link', 'yanka-addons' ),
                        'param_name' => 'google_plus',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Linkedin link', 'yanka-addons' ),
                        'param_name' => 'linkedin',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Skype link', 'yanka-addons' ),
                        'param_name' => 'skype',
                    ),
                    array(
                        'type'       => 'textfield',
                        'heading'    => esc_html__( 'Instagram link', 'yanka-addons' ),
                        'param_name' => 'instagram',
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Layout', 'yanka-addons' ),
                        'param_name' => 'layout',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )    => 'default',
                            esc_html__( 'With hover', 'yanka-addons' ) => 'hover',
                        ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Social buttons size', 'yanka-addons' ),
                        'param_name' => 'size',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' ) => '',
                            esc_html__( 'Small', 'yanka-addons' )   => 'small',
                            esc_html__( 'Large', 'yanka-addons' )   => 'large',
                        ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Layout', 'yanka-addons' ),
                        'param_name' => 'layout',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )    => 'default',
                            esc_html__( 'With hover', 'yanka-addons' ) => 'hover',
                        ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Social buttons style', 'yanka-addons' ),
                        'param_name' => 'style',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka-addons' )             => '',
                            esc_html__( 'Colored', 'yanka-addons' )             => 'colored',
                            esc_html__( 'Colored alternative', 'yanka-addons' ) => 'colored-alt',
                            esc_html__( 'Bordered', 'yanka-addons' )            => 'bordered',
                        ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Social buttons form', 'yanka-addons' ),
                        'param_name' => 'form',
                        'value'      => array(
                            esc_html__( 'Circle', 'yanka-addons' ) => 'circle',
                            esc_html__( 'Square', 'yanka-addons' ) => 'square',
                        ),
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'type'        => 'textfield',
                        'heading'     => esc_html__( 'Extra class name', 'yanka-addons' ),
                        'param_name'  => 'el_class',
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka-addons' )
                    )
                ),
            )
        );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_team_member' );
}
