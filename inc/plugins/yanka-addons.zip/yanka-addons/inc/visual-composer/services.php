<?php
/**
* ------------------------------------------------------------------------------------------------
* yanka service shortcode
* ------------------------------------------------------------------------------------------------
*/

if( ! function_exists( 'yanka_vc_map_services' ) ) {
    function yanka_vc_map_services() {
        vc_map(
            array(
                'name'     => esc_html__( 'Icon and Text', 'yanka' ),
                'base'     => 'jms_service',
                'icon'     => 'jms-icon',
                'category' => esc_html__( 'JMS Addons', 'yanka' ),
                'params'   => array(
                    array(
                        'param_name' => 'type',
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Icon type', 'yanka' ),
                        'value'      => array(
                            esc_html__( 'Icon', 'yanka' ) => 'icon',
                            esc_html__( 'Image', 'yanka' ) => 'image',
                        ),
                        'save_always' => true,
                    ),
                    array(
                        'type'    => 'dropdown',
                        'heading' => __( 'Icon library', 'yanka' ),
                        'value'   => array(
                            esc_html__( 'Font Awesome', 'yanka' ) => 'fontawesome',
                            esc_html__( 'icon stroke', 'yanka' )  => 'stroke',
                        ),
                        'save_always' => true,
                        'param_name'  => 'icon_type',
                        'description' => esc_html__( 'Select icon library.', 'yanka' ),
                        'dependency'  => array(
                            'element' => 'type',
                            'value'   => array( 'icon' ),
                        ),
                    ),
                    array(
                        'type'       => 'iconpicker',
                        'heading'    => esc_html__( 'Icon', 'yanka' ),
                        'param_name' => 'icon_fontawesome',
                        'value'      => 'fa fa-adjust',
                        'settings'   => array(
                            'emptyIcon'    => false,
                            'type'         => 'fontawesome',
                            'iconsPerPage' => 4000,
                        ),
                        'dependency' => array(
                            'element' => 'icon_type',
                            'value'   => 'fontawesome',
                        ),
                        'description' => esc_html__( 'Select icon from library.', 'yanka' ),
                    ),
                    array(
                        'type'       => 'iconpicker',
                        'heading'    => __( 'Icon', 'yanka' ),
                        'param_name' => 'icon_stroke',
                        'value'      => 'pe-7s-album',
                        'settings'   => array(
                            'emptyIcon'    => false,
                            'type'         => 'stroke',
                            'iconsPerPage' => 4000,
                        ),
                        'dependency' => array(
                            'element' => 'icon_type',
                            'value'   => 'stroke',
                        ),
                        'description' => __( 'Select icon from library.', 'yanka' ),
                    ),
                    array(
                        'type'        => 'attach_image',
                        'heading'     => esc_html__( 'Image', 'yanka' ),
                        'param_name'  => 'image',
                        'value'       => '',
                        'description' => esc_html__( 'Select image from media library.', 'yanka' ),
                        'dependency'  => array(
                            'element' => 'type',
                            'value'   => array( 'image' ),
                        ),
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Icon/Image alignment', 'yanka' ),
                        'param_name' => 'alignment',
                        'value'      => array(
                            esc_html__( 'Top', 'yanka' )   => 'top',
                            esc_html__( 'Left', 'yanka' )  => 'left',
                            esc_html__( 'Right', 'yanka' ) => 'right'
                        ),
                        'save_always' => true,
                    ),
                    array(
                        'type'        => 'colorpicker',
                        'heading'     => esc_html__( 'Custom color', 'yanka' ),
                        'param_name'  => 'icon_color',
                        'description' => esc_html__( 'Select custom icon color.', 'yanka' ),
                    ),
                    array(
                        'type'        => 'dropdown',
                        'heading'     => esc_html__( 'Size', 'yanka' ),
                        'param_name'  => 'icon_size',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka' )     => 'default',
                            esc_html__( 'Small', 'yanka' )       => 'small',
                            esc_html__( 'Large', 'yanka' )       => 'large',
                            esc_html__( 'Extra Large', 'yanka' ) => 'extra-large',
                        ),
                        'description' => esc_html__( 'Icon size.', 'yanka' ),
                        'save_always' => true,
                    ),
                    array(
                        'param_name'  => 'title',
                        'heading'     => esc_html__( 'Title', 'yanka' ),
                        'type'        => 'textfield',
                        'admin_label' => true,
                        'group'       => esc_html__( 'Title', 'yanka' )
                    ),
                    array(
                        'type'       => 'textarea',
                        'heading'    => esc_html__( 'Subtitle', 'yanka' ),
                        'param_name' => 'subtitle',
                        'group'      => esc_html__( 'Title', 'yanka' )
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Title size', 'yanka' ),
                        'param_name' => 'title_size',
                        'value'      => array(
                            esc_html__( 'Default', 'yanka' )     => 'default',
                            esc_html__( 'Small', 'yanka' )       => 'small',
                            esc_html__( 'Large', 'yanka' )       => 'large',
                            esc_html__( 'Extra Large', 'yanka' ) => 'extra-large',
                        ),
                        'save_always' => true,
                        'group' => esc_html__( 'Title', 'yanka' )
                    ),
                    array(
                        'type'       => 'dropdown',
                        'heading'    => esc_html__( 'Text alignment', 'yanka' ),
                        'param_name' => 'text_alignment',
                        'value'      => array(
                            esc_html__( 'Left', 'yanka' )   => 'left',
                            esc_html__( 'Center', 'yanka' ) => 'center',
                            esc_html__( 'Right', 'yanka' )  => 'right'
                        ),
                        'save_always' => true,
                        'group'       => esc_html__( 'Title', 'yanka' )
                    ),
                    array(
                        'type'             => 'colorpicker',
                        'heading'          => esc_html__( 'Title color', 'yanka' ),
                        'param_name'       => 'title_color',
                        'description'      => esc_html__( 'Select custom title color.', 'yanka' ),
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                        'group'            => esc_html__( 'Title', 'yanka' )
                    ),
                    array(
                        'type'             => 'colorpicker',
                        'heading'          => esc_html__( 'Subtitle color', 'yanka' ),
                        'param_name'       => 'subtitle_color',
                        'description'      => esc_html__( 'Select custom subtitle color.', 'yanka' ),
                        'edit_field_class' => 'vc_col-sm-6 vc_column',
                        'group'            => esc_html__( 'Title', 'yanka' )
                    ),
                    vc_map_add_css_animation(),
                    array(
                        'param_name'  => 'el_class',
                        'heading'     => esc_html__( 'Extra class name', 'yanka' ),
                        'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'yanka' ),
                        'type'        => 'textfield',
                    ),
                    array(
                        'type'          => 'css_editor',
                        'heading'       => esc_html__( 'Css', 'yanka' ),
                        'param_name'    => 'css',
                        'group'         => esc_html__( 'Design options', 'yanka' ),
                        'admin_label'   => false,
                    ),
                )
            )
        );
    }
    add_action( 'vc_before_init', 'yanka_vc_map_services' );
}
