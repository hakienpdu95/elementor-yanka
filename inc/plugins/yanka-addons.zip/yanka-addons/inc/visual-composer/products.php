<?php
/**
* ------------------------------------------------------------------------------------------------
* yanka products shortcode
* ------------------------------------------------------------------------------------------------
*/


if( ! function_exists( 'yanka_vc_map_products' ) ) {
	function yanka_vc_map_products() {
		vc_map( yanka_get_products_shortcode_map_params() );
	}
	add_action( 'vc_before_init', 'yanka_vc_map_products' );
}

if( ! function_exists( 'yanka_get_products_shortcode_params' ) ) {
	function yanka_get_products_shortcode_map_params() {
		return array(
			'name'        => esc_html__( 'Products (grid or carousel)', 'yanka' ),
 			'description' => esc_html__( 'Display products list', 'yanka' ),
 			'base'        => 'jms_products',
 			'icon'        => 'jms-icon',
 			'category'    => esc_html__( 'JMS Addons', 'yanka' ),
			'params' => yanka_get_products_shortcode_params()
		);
	}
}

if( ! function_exists( 'yanka_get_products_shortcode_params' ) ) {
	function yanka_get_products_shortcode_params() {
		//Get all terms of woocommerce
    	$product_cat = array();
    	$terms = get_terms( 'product_cat' );
    	if ( $terms && ! isset( $terms->errors ) ) {
    		foreach ( $terms as $key => $value ) {
    			$product_cat[$value->name] = $value->term_id;
    		}
    	}

		return apply_filters( 'yanka_get_products_shortcode_params', array(
			array(
				'param_name' => 'product_design',
				'heading'    => esc_html__( 'Display', 'yanka' ),
				'type' 	     => 'dropdown',
				'value'      => array(
					esc_html__( 'No Carousel', 'yanka' )     => 'nocarousel',
					esc_html__( 'Carousel', 'yanka' ) => 'carousel',
				),
				'admin_label' => true,
				'save_always' => true,
			),
			array(
				'param_name' => 'product_type',
				'heading'    => esc_html__( 'Display', 'yanka' ),
				'type' 	     => 'dropdown',
				'value'      => array(
					esc_html__( 'All products', 'yanka' )          => 'all',
					esc_html__( 'Recent products', 'yanka' )       => 'recent',
					esc_html__( 'Featured products', 'yanka' )     => 'featured',
					esc_html__( 'Sale products', 'yanka' )         => 'sale',
					esc_html__( 'Best selling products', 'yanka' ) => 'selling',
					esc_html__( 'Category', 'yanka' )              => 'cat',
					esc_html__( 'List of IDs', 'yanka' )           => 'ids',
				),
				'admin_label' => true,
				'save_always' => true,
			),
			array(
				'param_name'  => 'orderby',
				'heading'     => esc_html__( 'Order By', 'yanka' ),
				'description' => sprintf( wp_kses_post( 'Select how to sort retrieved products. More at %s. Default by Title', 'yanka' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				'type'        => 'dropdown',
				'value'       => array(
					esc_html__( 'Title', 'yanka' )         => 'title',
					esc_html__( 'Date', 'yanka' )          => 'date',
					esc_html__( 'ID', 'yanka' )            => 'ID',
					esc_html__( 'Author', 'yanka' )        => 'author',
					esc_html__( 'Modified', 'yanka' )      => 'modified',
					esc_html__( 'Random', 'yanka' )        => 'rand',
					esc_html__( 'Comment count', 'yanka' ) => 'comment_count',
					esc_html__( 'Menu order', 'yanka' )    => 'menu_order',
				),
				'admin_label' => true,
				'save_always' => true,
				'dependency'  => array(
					'element' => 'product_type',
					'value'   => array( 'all', 'featured', 'sale', 'rated', 'cat' ),
				),
			),
			array(
				'param_name'  => 'order',
				'heading'     => esc_html__( 'Order', 'yanka' ),
				'description' => sprintf( __( 'Designates the ascending or descending order. More at %s. Default by ASC', 'yanka' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				'type'        => 'dropdown',
				'value'       => array(
					esc_html__( 'Ascending', 'yanka' ) => 'ASC',
					esc_html__( 'Descending', 'yanka' ) => 'DESC',
				),
				'admin_label' => true,
				'save_always' => true,
				'dependency' => array(
					'element' => 'product_type',
					'value'   => array( 'all', 'featured', 'sale', 'rated' ),
				),
			),
			array(
				'type'       => 'autocomplete',
				'heading'    => esc_html__( 'Products', 'yanka' ),
				'description' => esc_html__( 'Input product ID or product SKU or product title to see suggestions', 'yanka' ),
				'param_name' => 'ids',
				'settings'   => array(
					'multiple'      => true,
					'sortable'      => true,
					'unique_values' => true,
					// In UI show results except selected. NB! You should manually check values in backend
				),
				'save_always' => true,
				'description' => esc_html__( 'Enter List of Products', 'yanka' ),
				'dependency' => array(
					'element' => 'product_type',
					'value'   => array( 'ids' )
				)
			),
			array(
				'type'       => 'hidden',
				'param_name' => 'skus',
				'dependency'  => array(
					'element' => 'product_type',
					'value'   => 'all',
				),
			),
			array(
				'heading'    => esc_html__( 'Product Category', 'yanka' ),
				'param_name' => 'cat_id',
				'type'       => 'dropdown',
				'value'      => $product_cat,
				'save_always' => true,
				'admin_label' => true,
				'description' => esc_html__( 'List of product categories', 'yanka' ),
				'dependency' => array(
					'element' => 'product_type',
					'value'   => 'cat',
				),
			),
			array(
				'param_name'  => 'total_items',
				'heading'     => esc_html__( 'Items per page', 'yanka' ),
				'description' => esc_html__( 'Number of items to show per page.', 'yanka' ),
				'type'        => 'textfield',
				'value'       => 8,
				'admin_label' => true,
			),
			array(
				'param_name'  => 'loadmore_product',
				'heading'     => esc_html__( 'Enable Load more Product', 'yanka' ),
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'         => 'no',
				'type'        => 'checkbox',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'nocarousel'
				),
			),
			array(
				'param_name'  => 'type_product',
				'heading'     => esc_html__( 'Product Type', 'yanka' ),
				'type'        => 'dropdown',
				'save_always' => true,
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array(
					esc_html__( 'Grid', 'yanka' )                   => 'grid',
					esc_html__( 'List', 'yanka' )                   => 'list',
				),
			),
			array(
				'param_name'  => 'style_product',
				'heading'     => esc_html__( 'Product Style', 'yanka' ),
				'description' => esc_html__( 'Consult Designs in Theme Option >> Shop', 'yanka' ),
				'type'        => 'dropdown',
				'save_always' => true,
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array(
					esc_html__( 'Inherit', 'yanka' )                   => '',
					esc_html__( 'Style 1', 'yanka' )                   => '1',
					esc_html__( 'Style 2', 'yanka' )                   => '2',
					esc_html__( 'Style 3', 'yanka' )                   => '3',
					esc_html__( 'Style 4', 'yanka' )                   => '4',
				),
				'dependency' => array(
					'element' => 'type_product',
					'value'   => 'grid'
				),
			),
			array(
				'param_name'  => 'style_product_list',
				'heading'     => esc_html__( 'Product Style', 'yanka' ),
				'type'        => 'dropdown',
				'save_always' => true,
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array(
					esc_html__( 'Style 1', 'yanka' )                    => 'list-1',
					esc_html__( 'Style 2', 'yanka' )                    => 'list-2',
				),
				'dependency' => array(
					'element' => 'type_product',
					'value'   => 'list'
				),
			),
			array(
				'param_name'  => 'style_thumb',
				'heading'     => esc_html__( 'Product Hover', 'yanka' ),
				'type'        => 'dropdown',
				'save_always' => true,
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array(
					esc_html__( 'Inherit', 'yanka' )                    				=> '',
					esc_html__( 'Zoom', 'yanka' )                    					=> '1',
					esc_html__( 'Move top to bottom', 'yanka' )                   		=> '2',
					esc_html__( 'Move bottom to top', 'yanka' )                   		=> '3',
					esc_html__('Move right to left', 'yanka') 							=> '4',
					esc_html__('Move left to right', 'yanka')                        	=> '5',
					esc_html__('Move top left to right bottom', 'yanka')              => '6',
					esc_html__('Move top right to bottom left', 'yanka')               => '7',
					esc_html__('Move right bottom to top right', 'yanka')              => '8',
					esc_html__('Move left bottom to top right', 'yanka')               => '9',
					esc_html__('Scale', 'yanka')                        				=> '10',
					esc_html__('Scale rotate', 'yanka')                        		=> '11',
					esc_html__('Skew Y rotate', 'yanka')                        		=> '12',
					esc_html__('Skew X rotate', 'yanka')                       		=> '13',
					esc_html__('Skew', 'yanka')                        				=> '14',


				),
			),
			array(
				'param_name'  => 'columns',
				'heading'     => esc_html__( 'Columns', 'yanka' ),
				'type'        => 'dropdown',
				'std'         => 4,
				'group'       => esc_html__( 'Design', 'yanka' ),
				'save_always' => true,
				'value'       => array(
					esc_html__( '1 Column', 'yanka' ) => 1,
					esc_html__( '2 Columns', 'yanka' ) => 2,
					esc_html__( '3 Columns', 'yanka' ) => 3,
					esc_html__( '4 Columns', 'yanka' ) => 4,
					esc_html__( '5 Columns', 'yanka' ) => 5,
					esc_html__( '6 Columns', 'yanka' ) => 6,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'nocarousel'
				),
			),
			array(
				'param_name'  => 'countdown',
				'heading'     => esc_html__( 'Enable countdown', 'yanka' ),
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'         => 'no',
				'type'        => 'checkbox',
			),
			array(
				'param_name'  => 'varition_woocommerce',
				'heading'     => esc_html__( 'Enable varition woocommerce', 'yanka' ),
				'group'       => esc_html__( 'Design', 'yanka' ),
				'value'       => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'         => 'no',
				'type'        => 'checkbox',
			),			
            array(
                'param_name'  => 'countdown_title',
                'heading'     => esc_html__('Countdown Title', 'yanka'),
                'group'       => esc_html__( 'Design', 'yanka' ),
                'type'        => 'textfield',
                'save_always' => true,
                'value'       => 'Offer Will End Through',
				'dependency' => array(
					'element' => 'countdown',
					'value'   => 'yes'
				),                
            ),			
			array(
				'param_name'  => 'product_spacing',
				'heading'     => esc_html__( 'Product spacing', 'yanka' ),
				'type'        => 'dropdown',
				'std'         => 30,
				'save_always' => true,
				'value'       => array(
					esc_html__( '0px', 'yanka' ) => 0,
					esc_html__( '10px', 'yanka' ) => 10,
					esc_html__( '20px', 'yanka' ) => 20,
					esc_html__( '30px', 'yanka' ) => 30,
					esc_html__( '40px', 'yanka' ) => 40,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'nocarousel'
				),
			),
			vc_map_add_css_animation(),
			array(
				'param_name'  => 'el_class',
				'heading'     => esc_html__( 'Extra class name', 'yanka' ),
				'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'yanka' ),
				'type'        => 'textfield',
				'admin_label' => false,
			),
			// SLIDER SETTINGS
			array(
				'param_name' => 'slider_opacity',
				'heading'    => esc_html__( 'Enable Slider Opacity', 'yanka' ),
				'type'       => 'checkbox',
				'group'      => esc_html__( 'Slider Settings', 'yanka' ),
				'value'      => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'        => 'no',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),

			array(
				'param_name'  => 'number_of_rows',
				'heading'     => esc_html__( 'Number of row', 'yanka' ),
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'type'        => 'textfield',
				'value'       => 1,
				'admin_label' => true,
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),

			array(
				'param_name'  => 'items_margin',
				'heading'     => esc_html__( 'Spacing between items', 'yanka' ),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => '30',
				'value'       => array(
					esc_html__( '0px', 'yanka' ) => 0,
					esc_html__( '10px', 'yanka' ) => 10,
					esc_html__( '20px', 'yanka' ) => 20,
					esc_html__( '30px', 'yanka' ) => 30,
					esc_html__( '40px', 'yanka' ) => 40,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			array(
				'param_name'  => 'items_desktop',
				'heading'     => esc_html__( 'Items Show On Desktop', 'yanka' ),
				'description' => esc_html__( 'Show number of items on desktop', 'yanka'),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 4,
				'value'       => array(
					esc_html__( '1 Item', 'yanka' ) => 1,
					esc_html__( '2 Items', 'yanka' ) => 2,
					esc_html__( '3 Items', 'yanka' ) => 3,
					esc_html__( '4 Items', 'yanka' ) => 4,
					esc_html__( '5 Items', 'yanka' ) => 5,
					esc_html__( '6 Items', 'yanka' ) => 6,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  => 'items_small_desktop',
				'heading'     => esc_html__( 'Items Show On Small Desktop', 'yanka' ),
				'description' => esc_html__( 'Show number of items on small desktop. Screen resolution of device >=992px and < 1199px.', 'yanka'),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 4,
				'value'       => array(
					esc_html__( '1 Item', 'yanka' )  => 1,
					esc_html__( '2 Items', 'yanka' ) => 2,
					esc_html__( '3 Items', 'yanka' ) => 3,
					esc_html__( '4 Items', 'yanka' ) => 4,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  => 'items_tablet',
				'heading'     => esc_html__( 'Items Show On Tablet Device', 'yanka' ),
				'description' => esc_html__( 'Show number of items on tablet. Screen resolution of device >=621px and < 992px', 'yanka'),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 3,
				'value'       => array(
					esc_html__( '1 Item', 'yanka' ) => 1,
					esc_html__( '2 Items', 'yanka' ) => 2,
					esc_html__( '3 Items', 'yanka' ) => 3,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  => 'items_mobile',
				'heading'     => esc_html__( 'Items Show On Mobile Device', 'yanka' ),
				'description' => esc_html__( 'Show number of items on mobile. Screen resolution of device >=445px and < 621px.', 'yanka'),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 2,
				'value'       => array(
					esc_html__( '1 Item', 'yanka' ) => 1,
					esc_html__( '2 Items', 'yanka' ) => 2,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  => 'items_small_mobile',
				'heading'     => esc_html__( 'Items Show On Small Mobile Device', 'yanka' ),
				'description' => esc_html__( 'Show number of items on small mobile. Screen resolution of device < 445px.', 'yanka'),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 1,
				'value'       => array(
					esc_html__( '1 Item', 'yanka' ) => 1,
					esc_html__( '2 Items', 'yanka' ) => 2,
				),
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			array(
				'param_name' => 'navigation',
				'heading'    => esc_html__( 'Enable Navigation', 'yanka' ),
				'type'       => 'checkbox',
				'group'      => esc_html__( 'Slider Settings', 'yanka' ),
				'value'      => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'        => 'no',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  => 'style_navigation',
				'heading'     => esc_html__( 'Arrow Styles', 'yanka' ),
				'type'        => 'dropdown',
				'group'       => esc_html__( 'Slider Settings', 'yanka' ),
				'std'         => 'icon_arrow',
				'value'       => array(
					esc_html__( 'Icon Arrow', 'yanka' ) => 'icon_arrow',
					esc_html__( 'Icon Arrow Box', 'yanka' ) => 'icon_box_arrow',
				),
				'dependency' => array(
					'element' => 'navigation',
					'value'   => 'yes'
				),
			),
			array(
				'param_name' => 'pagination',
				'heading'    => esc_html__( 'Enable Dots Pagination', 'yanka' ),
				'type'       => 'checkbox',
				'group'      => esc_html__( 'Slider Settings', 'yanka' ),
				'value'      => array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'        => 'no',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			 array(
				'param_name'  	=> 'autoplay',
				'heading'     	=> esc_html__( 'Autoplay', 'yanka' ),
				'description' 	=> esc_html__( 'Enables autoplay mode', 'yanka' ),
				'type'        	=> 'checkbox',
				'group'         => esc_html__( 'Slider Settings', 'yanka' ),
				'value'      	=> array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'        	=> 'no',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			array(
				'param_name'  	=> 'loop',
				'heading'     	=> esc_html__( 'Loop', 'yanka' ),
				'description' 	=> esc_html__( 'Inifnity loop. Duplicate last and first items to get loop illusion', 'yanka' ),
				'type'        	=> 'checkbox',
				'group'         => esc_html__( 'Slider Settings', 'yanka' ),
				'value'       	=> array( esc_html__( 'Yes', 'yanka' ) => 'yes' ),
				'std'        	=> 'no',
				'dependency' => array(
					'element' => 'product_design',
					'value'   => 'carousel'
				),
			),
			array(
				'type'        	=> 'css_editor',
				'heading'     	=> esc_html__( 'Css', 'yanka' ),
				'param_name'  	=> 'css',
				'group'       	=> esc_html__( 'Design options', 'yanka' ),
				'admin_label' 	=> false,
			)
		) );
	}
}

if ( !function_exists('yankaProductIdAutocompleteSuggester') ) {
    function yankaProductIdAutocompleteSuggester( $query ) {
        global $wpdb;
        $product_id = (int) $query;
        $post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.ID AS id, a.post_title AS title, b.meta_value AS sku
                    FROM {$wpdb->posts} AS a
                    LEFT JOIN ( SELECT meta_value, post_id  FROM {$wpdb->postmeta} WHERE `meta_key` = '_sku' ) AS b ON b.post_id = a.ID
                    WHERE a.post_type = 'product' AND ( a.ID = '%d' OR b.meta_value LIKE '%%%s%%' OR a.post_title LIKE '%%%s%%' )", $product_id > 0 ? $product_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

        $results = array();
        if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
            foreach ( $post_meta_infos as $value ) {
                $data = array();
                $data['value'] = $value['id'];
                $data['label'] = __( 'Id', 'js_composer' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . __( 'Title', 'js_composer' ) . ': ' . $value['title'] : '' ) . ( ( strlen( $value['sku'] ) > 0 ) ? ' - ' . __( 'Sku', 'js_composer' ) . ': ' . $value['sku'] : '' );
                $results[] = $data;
            }
        }

        return $results;
    }
    add_filter( 'vc_autocomplete_jms_products_ids_callback', 'yankaProductIdAutocompleteSuggester', 10, 1 );
}

if ( ! function_exists('yankaProductIdAutocompleteRender') ) {
    function yankaProductIdAutocompleteRender( $query ) {
        $query = trim( $query['value'] ); // get value from requested
        if ( ! empty( $query ) ) {
            // get product
            $product_object = wc_get_product( (int) $query );
            if ( is_object( $product_object ) ) {
                $product_sku = $product_object->get_sku();
                $product_title = $product_object->get_title();
                $product_id = $product_object->get_id();

                $product_sku_display = '';
                if ( ! empty( $product_sku ) ) {
                    $product_sku_display = ' - ' . __( 'Sku', 'js_composer' ) . ': ' . $product_sku;
                }

                $product_title_display = '';
                if ( ! empty( $product_title ) ) {
                    $product_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $product_title;
                }

                $product_id_display = __( 'Id', 'js_composer' ) . ': ' . $product_id;

                $data = array();
                $data['value'] = $product_id;
                $data['label'] = $product_id_display . $product_title_display . $product_sku_display;

                return ! empty( $data ) ? $data : false;
            }

            return false;
        }

        return false;
    }
    add_filter( 'vc_autocomplete_jms_products_ids_render', 'yankaProductIdAutocompleteRender', 10, 1 );
}
