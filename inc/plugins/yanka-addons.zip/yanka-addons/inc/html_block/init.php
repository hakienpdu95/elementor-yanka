<?php
/**
 * HTML BLOCK custom post type.
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

class Yanka_HTML_Block {
    function __construct() {
		add_action( 'init', array( __CLASS__, 'register_blocks' ) );

        // Add shortcode column to block list
		add_filter( 'manage_edit-html_block_columns', array($this, 'edit_html_blocks_columns') ) ;
		add_action( 'manage_html_block_posts_custom_column', array($this, 'manage_html_blocks_columns'), 10, 2 );
	}

    public static function register_blocks() {
 		$labels = array(
 			'name'                => _x( 'HTML Blocks', 'Post Type General Name', 'yanka-addons' ),
 			'singular_name'       => _x( 'HTML Block', 'Post Type Singular Name', 'yanka-addons' ),
 			'menu_name'           => __( 'HTML Blocks', 'yanka-addons' ),
 			'parent_item_colon'   => __( 'Parent Item:', 'yanka-addons' ),
 			'all_items'           => __( 'All Items', 'yanka-addons' ),
 			'view_item'           => __( 'View Item', 'yanka-addons' ),
 			'add_new_item'        => __( 'Add New Item', 'yanka-addons' ),
 			'add_new'             => __( 'Add New', 'yanka-addons' ),
 			'edit_item'           => __( 'Edit Item', 'yanka-addons' ),
 			'update_item'         => __( 'Update Item', 'yanka-addons' ),
 			'search_items'        => __( 'Search Item', 'yanka-addons' ),
 			'not_found'           => __( 'Not found', 'yanka-addons' ),
 			'not_found_in_trash'  => __( 'Not found in Trash', 'yanka-addons' ),
 		);

 		$args = array(
 			'label'               => __( 'html_block', 'yanka-addons' ),
 			'description'         => __( 'CMS Blocks for custom HTML to place in your pages', 'yanka-addons' ),
 			'labels'              => $labels,
 			'supports'            => array( 'title', 'editor' ),
 			'hierarchical'        => false,
 			'public'              => true,
 			'show_ui'             => true,
 			'show_in_menu'        => true,
 			'show_in_nav_menus'   => true,
 			'show_in_admin_bar'   => true,
 			'menu_position'       => 29,
 			'menu_icon'           => 'dashicons-welcome-widgets-menus',
 			'can_export'          => true,
 			'has_archive'         => false,
 			'exclude_from_search' => true,
 			'publicly_queryable'  => false,
 			'rewrite'             => false,
 			'capability_type'     => 'page',
 		);

 		register_post_type( 'html_block', $args );

 	}

    public function edit_html_blocks_columns( $columns ) {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => __( 'Title', 'yanka-addons' ),
			'shortcode' => __( 'Shortcode', 'yanka-addons' ),
			'date' => __( 'Date', 'yanka-addons' ),
		);
		return $columns;
	}

	public function manage_html_blocks_columns($column, $post_id) {
		switch( $column ) {
			case 'shortcode' :
				echo '[html_block id="'.$post_id.'"]';
			break;
		}
	}

}
$html_block = new Yanka_HTML_Block;
