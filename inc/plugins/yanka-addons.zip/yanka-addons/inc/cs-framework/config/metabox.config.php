<?php

if ( ! defined( 'ABSPATH' ) ) {
    die;
} // Cannot access pages directly.

$options = array();

if ( isset( $_GET['post'] ) && $_GET['post'] == get_option( 'page_for_posts' ) ) return;

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$footer_layouts = array();
$footer_layouts = array(
    '' => esc_html__( '- Select footer -', 'yanka-addons' ),
);

$jscomposer_templates_args = array(
    'orderby'          => 'title',
    'order'            => 'ASC',
    'post_type'        => 'footer_layout',
    'post_status'      => 'publish',
    'posts_per_page'   => 30,
);
$jscomposer_templates = get_posts( $jscomposer_templates_args );

if(count($jscomposer_templates) > 0) {
    foreach($jscomposer_templates as $jscomposer_template){
        $footer_layouts[$jscomposer_template->post_title] = $jscomposer_template->post_title;
    }
    $footer_default = $jscomposer_templates[0]->post_title;
}

$options[]    = array(
    'id'        => '_custom_page_options',
    'title'     => esc_html__('Page Options', 'yanka-addons'),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 's1',
            'fields' => array(

                array(
                    'id'       => 'header-logo-page',
                    'type'     => 'image',
                    'title'    => esc_html__('Logo', 'yanka-addons'),
                    'default' => false
                ),
                
                array(
                    'id'    => 'page-width',
                    'type'  => 'select',
                    'title' => esc_html__('Page width', 'yanka-addons'),
                    'options'  => array(
                        'inherit' => esc_html__( 'Inherit', 'yanka-addons' ),
                        'fullwidth' => esc_html__( 'Fullwidth', 'yanka-addons' ),
                        'boxed'   => esc_html__( 'Boxed', 'yanka-addons' ),
                    ),
                    'default'  => 'inherit',
                ),
                array(
                    'id'      => 'background-body',
                    'type'    => 'switcher',
                    'title'   => esc_html__( 'Body background', 'yanka-addons' ),
                    'default' => false
                ),
                array(
                    'id'      => 'body-bg',
                    'type'    => 'image',
                    'title'   => esc_html__( 'Body background image', 'yanka-addons' ),
                    'dependency'   => array( 'background-body', '==', 'true' ),
                ),
                array(
                    'id'      => 'body-bg-color',
                    'type'    => 'color_picker',
                    'title'   => esc_html__( 'Body background color', 'yanka-addons' ),
                    'dependency'   => array( 'background-body', '==', 'true' ),
                ),
                array(
					'id'      => 'pagehead',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable page title', 'yanka-addons' ),
					'default' => false
				),
                array(
                    'id'      => 'page-title',
                    'type'    => 'text',
                    'title'   => esc_html__( 'Page Title', 'yanka-addons' ),
                    'default' => '',
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
                    'id'      => 'pagehead-bg',
                    'type'    => 'image',
                    'title'   => esc_html__( 'Page heading background image', 'yanka-addons' ),
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
                    'id'      => 'pagehead-bg-color',
                    'type'    => 'color_picker',
                    'title'   => esc_html__( 'Page heading background color', 'yanka-addons' ),
                    'dependency'   => array( 'pagehead', '==', 'true' ),
                ),
                array(
					'id'      => 'breadcrumb',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Breadcrumb', 'yanka-addons' ),
					'default' => false,
				),
                array(
                    'id'    => 'page-header',
                    'type'  => 'select',
                    'title' => esc_html__('Header Style', 'yanka-addons'),
                    'desc'  => esc_html__('Choose the header style', 'yanka-addons'),
                    'options'  => array(
                        '' => esc_html__( '- Select header -', 'yanka-addons' ),
                        '1' => esc_html__( 'Header 1', 'yanka-addons' ),
                        '2' => esc_html__( 'Header 2', 'yanka-addons' ),
                        '3' => esc_html__( 'Header 3', 'yanka-addons' ),
                        '4' => esc_html__( 'Header 4', 'yanka-addons' ),
                        '5' => esc_html__( 'Header 5', 'yanka-addons' ),
                        '6' => esc_html__( 'Header 6', 'yanka-addons' ),
                        '7' => esc_html__( 'Header 7', 'yanka-addons' ),
                        '8' => esc_html__( 'Header 8', 'yanka-addons' ),
                        '9' => esc_html__( 'Header 9', 'yanka-addons' ),
                        '10' => esc_html__( 'Header 10', 'yanka-addons' ),
                        '11' => esc_html__( 'Header 11', 'yanka-addons' ),
                        '12' => esc_html__( 'Header 12', 'yanka-addons' ),
                        '13' => esc_html__( 'Header 13', 'yanka-addons' ),
                        '15' => esc_html__( 'Header 15', 'yanka-addons' ),
                        '18' => esc_html__( 'Header 18', 'yanka-addons' ),
                    ),
                    'default'  => '',
                ),

                array(
					'id'      => 'header-fullwidth',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Header fullwidth', 'yanka-addons' ),
					'default' => false,
				),

                array(
                    'id'       => 'page-footer',
                    'type'     => 'select',
                    'title'    => __( 'Footer Layout', 'yanka-addons' ),
                    'desc'      => esc_html__('Go to Footer Layout (admin table) to create/edit layout', 'yanka-addons'),
                    'options'   => $footer_layouts,
                    'default'   => ''
                ),
                array(
					'id'      => 'disable-footer',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Disable footer', 'yanka-addons' ),
                    'desc'    => esc_html__( 'You can disable footer for this page', 'yanka-addons' ),
					'default' => false,
				),
            ),
        ),
    ),
);

// -----------------------------------------
// Single Product Metabox Options             -
// -----------------------------------------
$options[]    = array(
    'id'        => '_custom_single_product_options',
    'title'     => esc_html__('Product Settings', 'yanka-addons'),
    'post_type' => 'product',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 's4',
            'fields' => array(
                array(
                    'id'      => 'wc-new-label',
                    'type'    => 'text',
                    'title'   => esc_html__( 'Add text label', 'yanka-addons' ),
                    'desc'    => esc_html__( 'Example: New or Hot... to make product highlights', 'yanka-addons' ),
                    'default' => '',
                ),
                array(
                    'id'    => 'wc-single-product-style',
                    'type'  => 'image_select',
                    'title' => esc_html__('Style', 'yanka-addons'),
                    'options'  => array(
                        '1' => CS_URI . '/assets/images/product/product-style-1.jpg',
                        '2' => CS_URI . '/assets/images/product/product-style-2.jpg',
                        '3' => CS_URI . '/assets/images/product/product-style-3.jpg',
                        '4' => CS_URI . '/assets/images/product/product-style-4.jpg',
                    ),
                    'default'  => '1',
                ),
                array(
					'id'      => 'wc-thumbnail-position',
					'type'    => 'select',
					'title'   => esc_html__( 'Thumbnail Position', 'yanka-addons' ),
					'options' => array(
						'left'    => esc_html__( 'Left', 'yanka-addons' ),
						'bottom'  => esc_html__( 'Bottom', 'yanka-addons' ),
						'right'   => esc_html__( 'Right', 'yanka-addons' ),
						'outside' => esc_html__( 'Outside', 'yanka-addons' )
					),
					'default'    => 'left',
					'dependency' => array( 'wc-single-product-style_1', '==', true ),
				),
                array(
					'id'      => 'wc-product-gallery-style',
					'type'    => 'image_select',
					'title'   => esc_html__( 'Product Gallery Style', 'yanka-addons' ),
					'options' => array(
                        '1' => CS_URI . '/assets/images/product/product-style-2.jpg',
                        '2' => CS_URI . '/assets/images/product/combined-grid-1.jpg',
                        '3' => CS_URI . '/assets/images/product/combined-grid-2.jpg',
					),
					'default'    => '1',
					'dependency' => array( 'wc-single-product-style_2', '==', true ),
				),
                array(
                    'id'      => 'wc-tabs-settings',
                    'type'    => 'select',
                    'title'   => esc_html__( 'Tabs Layout', 'yanka-addons' ),
                    'options' => array(
                        ''          => esc_html__( '-- Select --', 'yanka-addons' ),
                        'tabs'      => esc_html__( 'Tabs Full Width', 'yanka-addons' ),
                        'accordion' => esc_html__( 'Accordion Full Width', 'yanka-addons' )
                    ),
                    'default'    => '',
                ),
                array(
                    'id'      => 'wc-position-accordion',
                    'type'    => 'select',
                    'title'   => esc_html__( 'Position Accordion', 'yanka-addons' ),
                    'options' => array(
                        ''         => esc_html__( '-- Select --', 'yanka-addons' ),
                        'right'    => esc_html__( 'Right', 'yanka-addons' ),
                        'bottom'   => esc_html__( 'Bottom', 'yanka-addons' )
                    ),
                    'default'    => '',
                    'dependency' => array( 'wc-tabs-settings', '==', 'accordion' ),
                ),                
                array(
					'id'      => 'wc-enable-background',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Background?', 'yanka-addons' ),
					'default'    => false,
				),
                array(
					'id'      => 'wc-single-background-color',
					'type'    => 'color_picker',
					'title'   => esc_html__( 'Background Color', 'yanka-addons' ),
					'default'    => '',
					'dependency' => array( 'wc-enable-background', '==', true ),
				),
                array(
                    'id'      => 'wc-product-video-url',
					'type'    => 'text',
                    'title'   => esc_html__( 'Video URL', 'yanka-addons' ),
					'default'    => '',
				),
            ),
        ),
    ),
);

$options[] = array(
	'id'        => '_custom_wc_thumb_options',
	'title'     => esc_html__( 'Thumbnail Size', 'yanka-addons'),
	'post_type' => 'product',
	'context'   => 'side',
	'priority'  => 'default',
	'sections'  => array(
		array(
			'name'  => 's3',
			'fields' => array(
				array(
					'id'      => 'wc-thumbnail-size',
					'type'    => 'switcher',
					'title'   => esc_html__( 'Enable Large Thumbnail', 'yanka-addons' ),
					'default' => false
				),
			),
		),
	),
);




CSFramework_Metabox::instance( $options );
