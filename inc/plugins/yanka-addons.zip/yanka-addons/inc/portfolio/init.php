<?php
/**
 * Portfolio custom post type.
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

class Yanka_Addons_Portfolio {
	/**
	 * Construct function.
	 *
	 * @return  void
	 */
	function __construct() {
		add_action( 'init', array( __CLASS__, 'portfolio_init' ) );
	}

	/**
	 * Register a portfolio post type.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_post_type
	 */
	public static function portfolio_init() {
		$labels = array(
			'name'                => _x( 'Portfolio', 'Post Type General Name', 'yanka-addons' ),
			'singular_name'       => _x( 'Portfolio', 'Post Type Singular Name', 'yanka-addons' ),
			'menu_name'           => __( 'Portfolio', 'yanka-addons' ),
			'parent_item_colon'   => __( 'Parent Item:', 'yanka-addons' ),
			'all_items'           => __( 'All Items', 'yanka-addons' ),
			'view_item'           => __( 'View Item', 'yanka-addons' ),
			'add_new_item'        => __( 'Add New Item', 'yanka-addons' ),
			'add_new'             => __( 'Add New', 'yanka-addons' ),
			'edit_item'           => __( 'Edit Item', 'yanka-addons' ),
			'update_item'         => __( 'Update Item', 'yanka-addons' ),
			'search_items'        => __( 'Search Item', 'yanka-addons' ),
			'not_found'           => __( 'Not found', 'yanka-addons' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'yanka-addons' ),
		);

		register_post_type( 'portfolio',
			array(
				'label'               => __( 'portfolio', 'yanka-addons' ),
				'labels'              => $labels,
				'supports'            => array( 'title', 'editor', 'thumbnail' ),
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => true,
				'show_in_admin_bar'   => true,
				'menu_position'       => 28,
				'menu_icon'           => 'dashicons-images-alt2',
				'can_export'          => true,
				'has_archive'         => true,
				'exclude_from_search' => true,
				'publicly_queryable'  => true,
				'rewrite'             => array('slug' => 'portfolio'),
				'capability_type'     => 'page',
			)
 		);


		/**
		 * Create a taxonomy category for portfolio
		 *
		 * @uses  Inserts new taxonomy object into the list
		 * @uses  Adds query vars
		 *
		 * @param string  Name of taxonomy object
		 * @param array|string  Name of the object type for the taxonomy object.
		 * @param array|string  Taxonomy arguments
		 * @return null|WP_Error WP_Error if errors, otherwise null.
		 */

		$cat_labels = array(
			'name'					=> _x( 'Portfolio Categories', 'Taxonomy plural name', 'yanka-addons' ),
			'singular_name'			=> _x( 'Portfolio Category', 'Taxonomy singular name', 'yanka-addons' ),
			'search_items'			=> __( 'Search Categories', 'yanka-addons' ),
			'popular_items'			=> __( 'Popular Portfolio Categories', 'yanka-addons' ),
			'all_items'				=> __( 'All Portfolio Categories', 'yanka-addons' ),
			'parent_item'			=> __( 'Parent Category', 'yanka-addons' ),
			'parent_item_colon'		=> __( 'Parent Category', 'yanka-addons' ),
			'edit_item'				=> __( 'Edit Category', 'yanka-addons' ),
			'update_item'			=> __( 'Update Category', 'yanka-addons' ),
			'add_new_item'			=> __( 'Add New Category', 'yanka-addons' ),
			'new_item_name'			=> __( 'New Category', 'yanka-addons' ),
			'add_or_remove_items'	=> __( 'Add or remove Categories', 'yanka-addons' ),
			'choose_from_most_used'	=> __( 'Choose from most used text-domain', 'yanka-addons' ),
			'menu_name'				=> __( 'Categories', 'yanka-addons' ),
		);

		register_taxonomy( 'portfolio-cat', array( 'portfolio' ),
			array(
				'labels'            => $cat_labels,
				'public'            => true,
				'show_in_nav_menus' => true,
				'show_admin_column' => false,
				'hierarchical'      => true,
				'show_tagcloud'     => true,
				'show_ui'           => true,
				'query_var'         => true,
				'rewrite'           => true,
				'query_var'         => true,
				'capabilities'      => array(),
			)
		);

		// Register portfolio tag
		register_taxonomy( 'portfolio-tag',
			'portfolio',
			array(
				'hierarchical'          => false,
				'show_ui'               => true,
				'show_admin_column'     => true,
				'update_count_callback' => '_update_post_term_count',
				'query_var'             => true,
				'rewrite'               => array( 'slug' => 'portfolio-tag' ),
				'labels'                => array(
					'name'                       => __( 'Tags', 'yanka-addons' ),
					'singular_name'              => __( 'Tag', 'yanka-addons' ),
					'search_items'               => __( 'Search Tags', 'yanka-addons' ),
					'popular_items'              => __( 'Popular Tags', 'yanka-addons' ),
					'all_items'                  => __( 'All Tags', 'yanka-addons' ),
					'parent_item'                => null,
					'parent_item_colon'          => null,
					'edit_item'                  => __( 'Edit Tag', 'yanka-addons' ),
					'update_item'                => __( 'Update Tag', 'yanka-addons' ),
					'add_new_item'               => __( 'Add New Tag', 'yanka-addons' ),
					'new_item_name'              => __( 'New Tag Name', 'yanka-addons' ),
					'separate_items_with_commas' => __( 'Separate writers with commas', 'yanka-addons' ),
					'add_or_remove_items'        => __( 'Add or remove writers', 'yanka-addons' ),
					'choose_from_most_used'      => __( 'Choose from the most used writers', 'yanka-addons' ),
					'not_found'                  => __( 'No writers found.', 'yanka-addons' ),
					'menu_name'                  => __( 'Tags', 'yanka-addons' ),
				),
			)
		);

	}

}
$portfolio = new Yanka_Addons_Portfolio;
