<?php
/**
 * Plugin Name: Yanka Addons
 * Plugin URI: http://joommasters.com
 * Description: Currently supports the following theme functionality: shortcodes, CPT.
 * Version: 1.3
 * Author: JoomMasters
 * Author URI: http://joommasters.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: yanka-addons
 */

define( 'YANKA_ADDONS_URL', plugin_dir_url( __FILE__ ) );
define( 'YANKA_ADDONS_PATH', plugin_dir_path( __FILE__ ) );

if( ! function_exists('is_plugin_active') ){
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/*
 * Load plugin textdomain
 */

if ( !function_exists('yanka_addons_load_textdomain') ) {
    function yanka_addons_load_textdomain() {
        load_plugin_textdomain( 'yanka-addons', false, YANKA_ADDONS_PATH . 'languages' );
    }
    add_action( 'plugins_loaded', 'yanka_addons_load_textdomain' );
}

if ( !function_exists('yanka_admin_styles') ) {
    function yanka_admin_styles() {
        wp_enqueue_style('custom-style', YANKA_ADDONS_URL . 'assets/css/admin.css');
    }
    add_action('admin_print_styles', 'yanka_admin_styles');
}

function yanka_compress($variable){
	return base64_encode($variable);
}

function yanka_decompress($variable){
	return base64_decode($variable);
}

function yanka_get_svg($variable){
	return file_get_contents($variable);
}

/*
* [ CS Framework. ] - - - - - - - - - - - - - - - - - - - -
*/
require_once YANKA_ADDONS_PATH . 'inc/cs-framework/cs-framework.php';
require_once YANKA_ADDONS_PATH .'inc/footer_layout/init.php';
require_once YANKA_ADDONS_PATH .'inc/html_block/init.php';

/*
* [ Visual Composer. ] - - - - - - - - - - - - - - - - - - - -
*/
foreach (glob( YANKA_ADDONS_PATH . 'inc/visual-composer/*.php' ) as $filename) {
    include_once $filename;
}

/*
* [ Widget ] - - - - - - - - - - - - - - - - - - - -
*/
foreach (glob( YANKA_ADDONS_PATH . '/inc/widgets/*.php' ) as $filename) {
    include_once $filename;
}

/*
* [ Shortcode Visual Composer ] - - - - - - - - - - - - - - - - - - - -
*/
foreach (glob( YANKA_ADDONS_PATH . 'inc/shortcodes/*.php' ) as $filename) {
    include_once $filename;
}

/*
* [ Mega Menu. ] - - - - - - - - - - - - - - - - - - - -
*/
require_once YANKA_ADDONS_PATH . 'inc/megamenu/megamenu.php';

require_once ( YANKA_ADDONS_PATH .'inc/portfolio/init.php' );

function getCSSAnimation( $css_animation ) {
    $output = '';
    if ( '' !== $css_animation && 'none' !== $css_animation ) {
        wp_enqueue_script( 'waypoints' );
        wp_enqueue_style( 'animate-css' );
        $output = ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
    }

    return $output;
}

// Adding a custom Meta container to admin products pages
add_action( 'add_meta_boxes', 'yanka_create_additional_information_meta_box' );
if ( ! function_exists( 'yanka_create_additional_information_meta_box' ) ) {
    function yanka_create_additional_information_meta_box() {
        add_meta_box(
            'custom_product_meta_box',
            __( 'Additional Information', 'yanka' ),
            'yanka_add_additional_information_meta_box',
            'product',
            'normal',
            'default'
        );
    }
}